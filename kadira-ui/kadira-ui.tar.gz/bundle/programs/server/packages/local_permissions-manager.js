(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;

/* Package-scope variables */
var PermissionsMananger;

(function(){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// packages/local_permissions-manager/lib/permissions_manager.js                      //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
var PermissionsMan = function() {
  this._actions = {};
};

PermissionsMan.prototype.defineAction = function(action, roles) {
  var self = this;
  self._actions[action] = self._actions[action] || {};
  if(_.isArray(roles)){
    roles.forEach(function (role) {
      self._actions[action][role] = true;
    });
  } else if(roles.all === true){
    self._actions[action]["all"] = true;
  } else if(_.isArray(roles.except)) {
    self._actions[action]["except"] = roles.except;
  }
};

PermissionsMan.prototype.allowAction = function(action, role) {
  var excepts = this._actions[action]["except"];
  var isAllowed = false;

  if(excepts){
    if(_.contains(excepts, role)) {
      isAllowed = false;
    } else {
      isAllowed = true;
    }
  } else {
    isAllowed = !!this._actions[action]["all"]|| !!this._actions[action][role];
  }

  return isAllowed;
};

PermissionsMananger = new PermissionsMan();
////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////
//                                                                                    //
// packages/local_permissions-manager/lib/roles.js                                    //
//                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////
                                                                                      //
PermissionsMananger.roles = {};

var AppCollection = null;
var AppCollectionReadyDep = new Tracker.Dependency();

Meteor.startup(function() {
  if(Meteor.isClient) {
    // when we load this from a package like kadia-data
    // it's possible to Apps to be null since it can't inject values to 
    // this package (when we are testing)
    // But, when we use this package inside the app, Apps is there
    if(typeof Apps !== 'undefined') {
      AppCollection = Apps;
      AppCollectionReadyDep.changed();
    }
  } else {
    if(typeof Apps !== 'undefined') {
      // this is for running inside the app
      AppCollection = Apps
    } else {
      // this is for when used inside a package like kadira-data
      var c = new Mongo.Collection('temp_roles_collection');
      AppCollection = c.rawDatabase().collection('apps');
      AppCollection.update = Meteor.wrapAsync(AppCollection.update, AppCollection);
      AppCollection.findOne = Meteor.wrapAsync(AppCollection.findOne, AppCollection);
    }
  }
});

PermissionsMananger.roles.addRoleForApp = function(appId, userId, role) {
  var fields = {
    $addToSet: {
      perAppTeam: {
        userId: userId,
        role: role
      }
    }
  };
  return AppCollection.update({_id: appId}, fields);
};

PermissionsMananger.roles.removeRoleForApp = function(appId, userId, role) {
  var fields = {
    $pull: {
      perAppTeam: {
        userId: userId,
        role: role
      }
    }
  };
  return AppCollection.update({_id: appId}, fields);
};

PermissionsMananger.roles.isAllowed = function(action, appId, userId) {
  if(!AppCollection) {
    AppCollectionReadyDep.depend();
    return false;
  };

  var app = AppCollection.findOne({_id: appId}) || {};
  app.perAppTeam = app.perAppTeam || [];
  var role;
  if(app.owner === userId) {
    role = "owner";
  } else {
    app.perAppTeam.forEach(function (roleInfo) {
      if(roleInfo.userId === userId) {
        role = roleInfo.role;
      }
    });
  }

  return PermissionsMananger.allowAction(action, role);
};


PermissionsMananger.roles.usersWithRole = function(appId, role) {
  if(!AppCollection) {
    AppCollectionReadyDep.depend();
    return [];
  };

  var app = AppCollection.findOne({_id: appId, "perAppTeam.role": role}) || {};
  app.perAppTeam = app.perAppTeam || [];
  var users = [];
  app.perAppTeam.forEach(function (roleInfo) {
    if(roleInfo.role === role) {
      users.push(roleInfo.userId);
    }
  });
  return users;
};

PermissionsMananger.roles.getUserApps = function(userId) {
  var apps = AppCollection.find({"perAppTeam.userId": userId});
  return apps;
};

PermissionsMananger.roles.getAppOwner = function(appId) {
  var app = AppCollection.find({_id: appId}, {fields: {"perAppTeam": 1}}) || {};
  app.perAppTeam = app.perAppTeam || [];
  var owner;
  app.perAppTeam.forEach(function (roleInfo) {
    if(roleInfo.role === "owner") {
      owner = roleInfo.userId;
    }
  });
  return owner;
};
////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['local:permissions-manager'] = {}, {
  PermissionsMananger: PermissionsMananger
});

})();
