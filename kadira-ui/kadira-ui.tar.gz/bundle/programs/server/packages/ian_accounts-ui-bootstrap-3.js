(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['ian:accounts-ui-bootstrap-3'] = {};

})();
