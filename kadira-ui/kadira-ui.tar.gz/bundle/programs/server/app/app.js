var require = meteorInstall({"lib":{"i18n":{"en.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/i18n/en.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* eslint max-len: 0 */i18n.setDefaultLanguage("en");                                                                  // 1
var strings = {};                                                                                                      // 5
strings.common = {                                                                                                     // 7
  "or": "or",                                                                                                          // 8
  "copied_to_clipboard": "Copied '{$1}' to clipboard",                                                                 // 9
  "creating": "Creating ...",                                                                                          // 10
  "loading": "Loading ...",                                                                                            // 11
  "no_data": "No Data Found",                                                                                          // 12
  "sorted_by": "Sorted By",                                                                                            // 13
  "settings": "Settings",                                                                                              // 14
  "share": "Share",                                                                                                    // 15
  "alerts": "Alerts",                                                                                                  // 16
  "change": "Change",                                                                                                  // 17
  "save": "Save",                                                                                                      // 18
  "saving": "Saving..",                                                                                                // 19
  "cancel": "Cancel",                                                                                                  // 20
  "close": "Close",                                                                                                    // 21
  "confirm": "Confirm",                                                                                                // 22
  "add": "Add",                                                                                                        // 23
  "resend": "Resend",                                                                                                  // 24
  "load_more": "Load more",                                                                                            // 25
  "back": "Back",                                                                                                      // 26
  "delete": "Delete",                                                                                                  // 27
  "share_this": "SHARE THIS",                                                                                          // 28
  "show_hosts": "Show Hosts",                                                                                          // 29
  "site_name": "Kadira",                                                                                               // 30
  "analyze": "Analyze",                                                                                                // 31
  "upgrade": "Upgrade"                                                                                                 // 32
};                                                                                                                     // 7
strings.signIn = {                                                                                                     // 35
  "already_connected_meteor_dev_account": "This Meteor Developer account is already associated with an existing Kadira account.",
  "already_registed_via_email": "Please login with your email: \"{$1}\" and connect your Meteor developer account from the profile.",
  "privacy_policy_links": "By clicking Sign Up, you agree to our <a href='{{$1}}'>Privacy Policy</a> and <a href='{{$2}}'>Terms of Use</a>",
  "sign_in_with_email": "Sign In with your email address",                                                             // 41
  "forgot_your_password": "Forgot your password?",                                                                     // 42
  "sign_in": "Sign In",                                                                                                // 43
  "sign_up": "Sign Up",                                                                                                // 44
  "dont_have_a_kadira_account": "Dont have a Kadira account?",                                                         // 45
  "already_have_a_kadira_account": "Already have a Kadira account?",                                                   // 46
  "email": "Email",                                                                                                    // 47
  "password": "Password",                                                                                              // 48
  "sign_in_message": "Sign in to view this page"                                                                       // 49
};                                                                                                                     // 35
strings.apps = {                                                                                                       // 52
  "create_app_form_title": "create new app",                                                                           // 53
  "create_app": "Create App",                                                                                          // 54
  "create_new": "Create New",                                                                                          // 55
  "app_name": "App Name",                                                                                              // 56
  "my_apps": "My Apps",                                                                                                // 57
  "created_date": "Created Date"                                                                                       // 58
};                                                                                                                     // 52
strings.app = {                                                                                                        // 61
  "configure_your_app": "Configure Your App",                                                                          // 62
  "config_install_pkg": "Install our Smart Package",                                                                   // 63
  "config_connect_code": "Connect to Kadira using one of the following methods.",                                      // 64
  "config_learn_more": "Your data will be available within one minute. For more info, please refer the <a href=\"https://kadira.io/academy/getting-started-with-kadira/\" class='link'>Getting Started Guide</a>.",
  "config_configurations": "Raw AppId and appSecret",                                                                  // 66
  "config_other_way": "If you need to configure your app in some other way",                                           // 67
  "app_id": "App ID",                                                                                                  // 68
  "app_secret": "App Secret",                                                                                          // 69
  "summary": "Summary",                                                                                                // 70
  "trends": "Trends",                                                                                                  // 71
  "predictions": "Relations & Predictions",                                                                            // 72
  "cpu_profiler": "CPU Profiler",                                                                                      // 73
  "pub_sub": "Pub/Sub",                                                                                                // 74
  "methods": "Methods",                                                                                                // 75
  "overview": "Overview",                                                                                              // 76
  "live_queries": "Live Queries",                                                                                      // 77
  "charts": "Charts",                                                                                                  // 78
  "observer_info": "Observer Info",                                                                                    // 79
  "viewing_app_as_admin": "Viewing app as admin",                                                                      // 80
  "documents": "Documents & Updates"                                                                                   // 81
};                                                                                                                     // 61
strings.validations = {                                                                                                // 84
  "app_name_validation_failed": "Please enter App Name using alphanumerical characters and \"-\" only!",               // 85
  "app_name_too_long": "App Name should not be longer than 50 characters!",                                            // 86
  "url_validation_failed": "Please enter a valid url",                                                                 // 87
  "email_validation_failed": "Please enter a valid email"                                                              // 88
};                                                                                                                     // 84
strings.share = {                                                                                                      // 91
  "application_sharing": "Application Sharing",                                                                        // 92
  "owner": "Owner",                                                                                                    // 93
  "app_owner_email_empty": "Please enter new app owner's email",                                                       // 94
  "enter_app_name_to_confirm": "Please enter app name to confirm ownership change",                                    // 95
  "enter_app_name_to_confirm_failed": "Please enter app name correctly to confirm ownership change",                   // 96
  "collaborator_email_empty": "Please enter collaborator's email",                                                     // 97
  "changed_app_ownership_to": "Changed app ownership to {$1}",                                                         // 98
  "add_collaborator_not_permitted": "You are not authorized to add collaborators",                                     // 99
  "remove_collaborator_not_permitted": "You are not authorized to remove collaborators",                               // 100
  "reached_collaborators_limit": "You have reached maximum number of collaborators limit. Please upgrade.",            // 101
  "could_not_add_collaborator": "could not add collaborator: {$1}",                                                    // 102
  "pending_collaborator_already_invited": "you have already invited {$1} to collaborate",                              // 103
  "pending_collaborators": "Pending Collaborators",                                                                    // 104
  "pending_user_invite_email_tmpl_subject": "Accept Invitation for App: <%= appName %>",                               // 105
  "collaborator_invite_email_tmpl": "Hello, <br/><br> Congratulations! You now have access to <b><%= appName %></b> on Kadira. We look forward to see you at kadira often. <br> Please <a href='<%= inviteUrl %>'>Visit Kadira</a> to begin.<br><br>Thank You!",
  "new_app_owner_not_registered": "{$1} is not a registered user in Kadira. Please ask him to register first.",        // 107
  "invite_not_found": "Invite not found",                                                                              // 108
  "invite_again_success": "Invited again successfully",                                                                // 109
  "already_invited_collaborator": "You have added this collaborator already",                                          // 110
  "failed_to_add_collaborator": "failed to add collaborator",                                                          // 111
  "notify_new_owner_subject": "You received ownership of application : <%= appName %>",                                // 112
  "notify_new_owner_email_templ": "Hello, <br/><br> Congratulations! You are invited to become the owner of application <a href='<%= appLink %>'><%= appName %></a> on Kadira. Click <a href='<%= inviteUrl %>'> here </a> to accept invitation.",
  "change_owner_not_permitted": "You are not authorized to change app ownership",                                      // 114
  "remove_collaborator_success": "Collaborator removed successfully",                                                  // 115
  "add_collaborator_success": "Collaborator added successfully",                                                       // 116
  "new_owner_email": "New Owner Email",                                                                                // 117
  "enter_app_name": "Enter App Name",                                                                                  // 118
  "collaborator_email": "collaborator's email",                                                                        // 119
  "cancel_invite_success": "Canceled collaboration invite successfully",                                               // 120
  "processing_invitation": "please wait ...",                                                                          // 121
  "collaborators": "Collaborators",                                                                                    // 122
  "app_not_found": "App Not found",                                                                                    // 123
  "already_owner": "you are already the owner of this application",                                                    // 124
  "remove_pending_user_denied": "You are not authorized to remove pending users",                                      // 125
  "resending_invite_defenied": "You are not authorized to reinvite users",                                             // 126
  "upgrade_to_add_collaborators": "Please upgrade your plan to manage collaborators",                                  // 127
  "only_paid_users_can_accept_apps": "Please upgrade your plan to accept this app ownership"                           // 128
};                                                                                                                     // 91
strings.tools = {                                                                                                      // 131
  "take_remote_profile": "Take a Remote Profile",                                                                      // 132
  "visit_kadira_debug_to_local_profiles": "Visit Kadira Debug to take local profiles",                                 // 133
  "install_kadira_profiler_msg": "Make sure you've installed <a href=\"https://github.com/meteorhacks/kadira-profiler\" target=\"_blank\"><b>Kadira Profiler package</b></a> into your app:<code>meteor add meteorhacks:kadira-profiler</code>",
  "duration": "Duration",                                                                                              // 135
  "name": "Name",                                                                                                      // 136
  "invalid_job_name": "Please use alpha numeric charactors only",                                                      // 137
  "seconds": "{$1} Seconds",                                                                                           // 138
  "minute": "1 minute",                                                                                                // 139
  "minutes": "{$1} minutes",                                                                                           // 140
  "job_delete_confirm": "Are you sure you want to delete this profile? ",                                              // 141
  "delete_job_success": "profile deleted",                                                                             // 142
  "take_a_local_profile": "Take a Local Profile",                                                                      // 143
  "learn_how_to_analyze_profile": "Learn how to analyze a CPU Profile",                                                // 144
  "cpu_analyzer": "CPU Analyzer",                                                                                      // 145
  "could_not_load_cpu_profile": "Could not load CPU profile"                                                           // 146
};                                                                                                                     // 131
strings.tools.labels = {                                                                                               // 149
  "pubsub-initial-adds": "Sending initial subscription data",                                                          // 150
  "pubsub-sendAdded": "Sending new documents",                                                                         // 151
  "pubsub-sendChanged": "Sending document changes",                                                                    // 152
  "pubsub-sendRemoved": "Sending document remove messages",                                                            // 153
  "crossbar-listen": "Listening for Crossbar",                                                                         // 154
  "crossbar-fire": "Firing Crossbar",                                                                                  // 155
  "mongo-receive": "Receiving data from MongoDB",                                                                      // 156
  "data-send": "Sending other data via DDP",                                                                           // 157
  "cursor-observeChanges": "Cursor.observeChanges",                                                                    // 158
  "cursor-fetch": "Cursor.fetch",                                                                                      // 159
  "cursor-map": "Cursor.map",                                                                                          // 160
  "cursor-forEach": "Cursor.forEach",                                                                                  // 161
  "cursor-count": "Cursor.count",                                                                                      // 162
  "cursor-observe": "Cursor.observe",                                                                                  // 163
  "mongo-insert": "Inserting MongoDB documents",                                                                       // 164
  "mongo-update": "Updating MongoDB documents",                                                                        // 165
  "mongo-remove": "Removing MongoDB documents",                                                                        // 166
  "oplog-initial-query": "Initial DB Quering (with oplog)",                                                            // 167
  "proto._runQuery": "DB Quering (with oplog)",                                                                        // 168
  "mongo-parsing": "Parsing incoming MongoDB documents"                                                                // 169
};                                                                                                                     // 149
strings.dashboard = {};                                                                                                // 172
strings.dashboard.pubsub = {                                                                                           // 174
  "sub_rate": "Sub Rate",                                                                                              // 175
  "unsub_rate": "Unsub Rate",                                                                                          // 176
  "avg_response_time": "Response Time",                                                                                // 177
  "low_observer_reuse": "Low Observer Reuse",                                                                          // 178
  "high_observer_reuse": "High Observer Reuse",                                                                        // 179
  "shortest_lifespan": "Shortest Lifespan",                                                                            // 180
  "active_subs": "Active Subs",                                                                                        // 181
  "created_observers": "Created Observers",                                                                            // 182
  "deleted_observers": "Deleted Observers",                                                                            // 183
  "cached_observers": "Reused Observers",                                                                              // 184
  "total_observer_handlers": "Total Observer Handlers"                                                                 // 185
};                                                                                                                     // 174
strings.dashboard.methods = {                                                                                          // 188
  "throughput": "Throughput",                                                                                          // 189
  "response_time": "Response Time",                                                                                    // 190
  "errors": "Errors",                                                                                                  // 191
  "wait_time": "Wait Time",                                                                                            // 192
  "db_time": "DB Time",                                                                                                // 193
  "email_time": "Email Time",                                                                                          // 194
  "async_time": "Async Time",                                                                                          // 195
  "compute_time": "Compute Time",                                                                                      // 196
  "http_time": "HTTP Time"                                                                                             // 197
};                                                                                                                     // 188
strings.dashboard.errors = {                                                                                           // 200
  "count": "Error Count",                                                                                              // 201
  "last_seen": "Last Seen"                                                                                             // 202
};                                                                                                                     // 200
strings.dashboard.liveQueries = {                                                                                      // 205
  "polled_doc_count": "Fetched Doc. Count",                                                                            // 206
  "changed_doc_count": "Changed Doc. Count",                                                                           // 207
  "inserted_doc_count": "Inserted Doc. Count",                                                                         // 208
  "updated_doc_count": "Updated Doc. Count",                                                                           // 209
  "deleted_doc_count": "Deleted Doc. Count"                                                                            // 210
};                                                                                                                     // 205
strings.settings = {                                                                                                   // 213
  "application_settings": "Application Settings",                                                                      // 214
  "app_info": "App Info",                                                                                              // 215
  "app_name": "App Name",                                                                                              // 216
  "update_btn_text": "Update",                                                                                         // 217
  "appid_and_app_secret": "App Id and Secret",                                                                         // 218
  "via_code": "Via Code",                                                                                              // 219
  "via_meteor_settings": "Via Meteor Settings",                                                                        // 220
  "via_environmental_variables": "Via Environmental Variables",                                                        // 221
  "regenerate_btn_text": "Regenerate",                                                                                 // 222
  "confirm_btn_text": "Confirm",                                                                                       // 223
  "cancel_btn_text": "Cancel",                                                                                         // 224
  "delete_the_app": "Delete The App",                                                                                  // 225
  "delete_btn_text": "Delete",                                                                                         // 226
  "pricing": "Pricing"                                                                                                 // 227
};                                                                                                                     // 213
strings.alerts = {                                                                                                     // 230
  "application_alerts": "Alerts"                                                                                       // 231
};                                                                                                                     // 230
strings.emails = {                                                                                                     // 234
  "reset_password_subject": "Reset your Kadira passsword"                                                              // 235
};                                                                                                                     // 234
strings.profiler = {                                                                                                   // 238
  "profiler_denied_msg": "Update your plan to profile the <a href=\"{$1}\">CPU remotely</a>",                          // 239
  "profiler_delete_denied_msg": "You are not authorized to delete this profile",                                       // 240
  "not_authorized": "You are not authorized to view this CPU profile"                                                  // 241
};                                                                                                                     // 238
strings.ranges = {                                                                                                     // 244
  "range_1hour": "Range: 1 Hour",                                                                                      // 245
  "range_3hour": "Range: 3 Hours",                                                                                     // 246
  "range_8hour": "Range: 8 Hours",                                                                                     // 247
  "range_24hour": "Range: 24 Hours",                                                                                   // 248
  "range_3day": "Range: 3 Days",                                                                                       // 249
  "range_1week": "Range: Week",                                                                                        // 250
  "range_30day": "Range: 30 Days"                                                                                      // 251
};                                                                                                                     // 244
i18n.map("en", strings);                                                                                               // 254
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"accounts_helpers.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/accounts_helpers.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
AccountsHelpers = {};                                                                                                  // 1
                                                                                                                       //
AccountsHelpers.isMeteorLoginConnected = function () {                                                                 // 2
  function isMeteorLoginConnected(user) {                                                                              // 2
    var isConnected = user && user.services && user.services["meteor-developer"] && user.services["meteor-developer"].emails && user.services["meteor-developer"].emails.length > 0;
    return isConnected;                                                                                                // 9
  }                                                                                                                    // 10
                                                                                                                       //
  return isMeteorLoginConnected;                                                                                       // 2
}();                                                                                                                   // 2
                                                                                                                       //
AccountsHelpers.getUserEmail = function () {                                                                           // 12
  function _getUserEmail(user) {                                                                                       // 12
    if (AccountsHelpers.isMeteorLoginConnected(user)) {                                                                // 13
      var primaryEmail = _.find(user.services && user.services["meteor-developer"].emails, function (email) {          // 14
        return email.primary === true;                                                                                 // 17
      });                                                                                                              // 18
                                                                                                                       //
      primaryEmail = primaryEmail || {};                                                                               // 20
      var email = primaryEmail.address || user.services["meteor-developer"].emails[0].address;                         // 21
      return email;                                                                                                    // 23
    } else if (user.emails && user.emails[0].address) {                                                                // 24
      return user.emails[0].address;                                                                                   // 25
    }                                                                                                                  // 26
  }                                                                                                                    // 27
                                                                                                                       //
  return _getUserEmail;                                                                                                // 12
}();                                                                                                                   // 12
                                                                                                                       //
AccountsHelpers.getName = function (user) {                                                                            // 29
  if (user.billingInfo && user.billingInfo.name) {                                                                     // 30
    return user.billingInfo.name;                                                                                      // 31
  }                                                                                                                    // 32
                                                                                                                       //
  if (user.profile && user.profile.name) {                                                                             // 34
    return user.profile.name;                                                                                          // 35
  }                                                                                                                    // 36
};                                                                                                                     // 37
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"autourl.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/autourl.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// A way to automatically decide the appId                                                                             // 1
// This is very healful for sending marketing messages and emails                                                      // 2
// Also works with in app links (without page refreshes)                                                               // 3
// Usage: Simply code an appUrl. Then replace the appId with AUTO                                                      // 4
//  see: http://localhost:3000/apps/AUTO/errors/overview                                                               // 5
Autourl = function () {                                                                                                // 7
  function Autourl() {                                                                                                 // 7
    this._previousContext = null;                                                                                      // 8
    this.trackPreviousContext = this.trackPreviousContext.bind(this);                                                  // 9
    this.handle = this.handle.bind(this);                                                                              // 10
  }                                                                                                                    // 11
                                                                                                                       //
  return Autourl;                                                                                                      // 7
}();                                                                                                                   // 7
                                                                                                                       //
Autourl.prototype.trackPreviousContext = function (context) {                                                          // 13
  this._previousContext = context;                                                                                     // 14
};                                                                                                                     // 15
                                                                                                                       //
Autourl.prototype.handle = function (context, redirect) {                                                              // 17
  // When we see appId === AUTO                                                                                        // 18
  // Then, we'll tring to figure our an appId automatically                                                            // 19
  if (context.params.appId !== "AUTO") {                                                                               // 20
    return false;                                                                                                      // 21
  }                                                                                                                    // 22
                                                                                                                       //
  var appId = null;                                                                                                    // 24
                                                                                                                       //
  if (this._previousContext && this._previousContext.params.appId) {                                                   // 25
    appId = this._previousContext.params.appId;                                                                        // 26
  } else {                                                                                                             // 27
    var app = Apps.findOne() || {};                                                                                    // 28
    appId = app._id;                                                                                                   // 29
  }                                                                                                                    // 30
                                                                                                                       //
  if (appId) {                                                                                                         // 32
    var queryParams = context.queryParams;                                                                             // 33
    var params = context.params;                                                                                       // 34
    params.appId = appId;                                                                                              // 35
    redirect("app", params, queryParams);                                                                              // 36
  } else {                                                                                                             // 37
    redirect("/");                                                                                                     // 38
  }                                                                                                                    // 39
};                                                                                                                     // 40
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"collections.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Apps = new Mongo.Collection("apps");                                                                                   // 1
PendingUsers = new Mongo.Collection("pendingUsers");                                                                   // 2
ErrorsMeta = new Mongo.Collection("errorsMeta");                                                                       // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/router.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Subscriptions = new SubsManager();                                                                                     // 1
var autourl = new Autourl();                                                                                           // 2
                                                                                                                       //
FlowRouter.subscriptions = function () {                                                                               // 4
  this.register("apps", Subscriptions.subscribe("apps.userOwned"));                                                    // 5
  this.register("userInfo", Subscriptions.subscribe("user.userInfo"));                                                 // 6
  this.register("getCollabApps", Subscriptions.subscribe("apps.collaboratored"));                                      // 7
};                                                                                                                     // 9
                                                                                                                       //
FlowRouter.triggers.enter([setTitles]);                                                                                // 11
FlowRouter.triggers.enter([redirectOnKadiraDebug], {                                                                   // 12
  except: ["redirect"]                                                                                                 // 12
});                                                                                                                    // 12
FlowRouter.triggers.exit([autourl.trackPreviousContext]);                                                              // 13
FlowRouter.route("/", {                                                                                                // 15
  action: function () {                                                                                                // 16
    // sending an empty options object to make sure options.ignoreLoginCheck                                           // 17
    // revalidated                                                                                                     // 18
    BlazeLayout.render("layout.main", {                                                                                // 19
      main: "apps"                                                                                                     // 19
    });                                                                                                                // 19
  }                                                                                                                    // 20
});                                                                                                                    // 15
FlowRouter.route("/sign-in", {                                                                                         // 23
  action: function () {                                                                                                // 24
    var options = {                                                                                                    // 25
      isSignInPage: true,                                                                                              // 26
      ignoreLoginCheck: true                                                                                           // 27
    };                                                                                                                 // 25
    BlazeLayout.render("layout.main", {                                                                                // 30
      main: "signIn",                                                                                                  // 30
      options: options                                                                                                 // 30
    });                                                                                                                // 30
  }                                                                                                                    // 31
});                                                                                                                    // 23
FlowRouter.route("/sign-up", {                                                                                         // 34
  action: function () {                                                                                                // 35
    var options = {                                                                                                    // 36
      isSignUpPage: true,                                                                                              // 37
      ignoreLoginCheck: true                                                                                           // 38
    };                                                                                                                 // 36
    BlazeLayout.render("layout.main", {                                                                                // 41
      main: "signIn",                                                                                                  // 41
      options: options                                                                                                 // 41
    });                                                                                                                // 41
  }                                                                                                                    // 42
});                                                                                                                    // 34
FlowRouter.route("/forgot-password", {                                                                                 // 45
  action: function () {                                                                                                // 46
    var options = {                                                                                                    // 47
      ignoreLoginCheck: true                                                                                           // 48
    };                                                                                                                 // 47
    BlazeLayout.render("layout.main", {                                                                                // 50
      main: "forgotPassword",                                                                                          // 51
      options: options                                                                                                 // 52
    });                                                                                                                // 50
  }                                                                                                                    // 54
});                                                                                                                    // 45
FlowRouter.route("/create-app", {                                                                                      // 57
  action: function () {                                                                                                // 58
    BlazeLayout.render("layout.main", {                                                                                // 59
      main: "apps.create"                                                                                              // 59
    });                                                                                                                // 59
  }                                                                                                                    // 60
});                                                                                                                    // 57
FlowRouter.route("/debug", {                                                                                           // 63
  name: "debug",                                                                                                       // 64
  action: function () {                                                                                                // 65
    var options = {                                                                                                    // 66
      ignoreLoginCheck: true                                                                                           // 67
    };                                                                                                                 // 66
    BlazeLayout.render("layout.main", {                                                                                // 69
      main: "debug",                                                                                                   // 69
      options: options                                                                                                 // 69
    });                                                                                                                // 69
  }                                                                                                                    // 70
});                                                                                                                    // 63
FlowRouter.route("/apps/:appId/:section/:subSection", {                                                                // 73
  name: "app",                                                                                                         // 74
  triggersEnter: [legacyUrlRedirects, redirectToNewProfiler, checkQueryParam, resoultionsToRanges, UrlStateManager.triggers.saveGlobalQueryParams, UrlStateManager.triggers.saveSubSection, UrlStateManager.triggers.saveLastPath, autourl.handle],
  subscriptions: function (params) {                                                                                   // 85
    var appId = params.appId;                                                                                          // 86
    this.register("pendingUsers", Subscriptions.subscribe("apps.pendingUsers", appId));                                // 88
    this.register("collaborators", Subscriptions.subscribe("apps.collaborators", appId));                              // 90
    this.register("admin", Subscriptions.subscribe("apps.admin", appId));                                              // 92
  },                                                                                                                   // 93
  action: function () {                                                                                                // 94
    BlazeLayout.render("layout.main", {                                                                                // 95
      main: "app"                                                                                                      // 95
    });                                                                                                                // 95
  }                                                                                                                    // 96
});                                                                                                                    // 73
FlowRouter.route("/invite/:inviteId", {                                                                                // 99
  action: function () {                                                                                                // 100
    BlazeLayout.render("layout.main", {                                                                                // 101
      main: "app.share.invite"                                                                                         // 101
    });                                                                                                                // 101
  }                                                                                                                    // 102
});                                                                                                                    // 99
FlowRouter.route("/cpf/:jobId", {                                                                                      // 105
  name: "sharedCpuProfile",                                                                                            // 106
  action: function () {                                                                                                // 107
    var options = {                                                                                                    // 108
      ignoreLoginCheck: true                                                                                           // 109
    };                                                                                                                 // 108
    BlazeLayout.render("layout.main", {                                                                                // 111
      main: "app.tools.cpu",                                                                                           // 112
      options: options                                                                                                 // 112
    });                                                                                                                // 111
  }                                                                                                                    // 114
});                                                                                                                    // 105
FlowRouter.route("/account/:section?", {                                                                               // 117
  triggersEnter: [function (context) {                                                                                 // 118
    // only allowed these sections.                                                                                    // 119
    // otherwise, redirects to the billing section                                                                     // 120
    var sections = ["billing", "plans", "profile"];                                                                    // 121
    var isAllow = sections.indexOf(context.params.section);                                                            // 122
    BlazeLayout.render("layout.main", {                                                                                // 123
      main: "account"                                                                                                  // 123
    });                                                                                                                // 123
                                                                                                                       //
    if (isAllow < 0) {                                                                                                 // 124
      FlowRouter.redirect("/account/billing");                                                                         // 125
    }                                                                                                                  // 126
  }],                                                                                                                  // 127
  action: function () {                                                                                                // 128
    BlazeLayout.render("layout.main", {                                                                                // 129
      main: "account"                                                                                                  // 129
    });                                                                                                                // 129
  }                                                                                                                    // 130
});                                                                                                                    // 117
FlowRouter.route("/mt/:traceId/:appId?", {                                                                             // 133
  action: function () {                                                                                                // 134
    var options = {                                                                                                    // 135
      ignoreLoginCheck: true                                                                                           // 136
    };                                                                                                                 // 135
    BlazeLayout.render("layout.main", {                                                                                // 138
      main: "traceExplorer.shared",                                                                                    // 139
      options: options                                                                                                 // 140
    });                                                                                                                // 138
  }                                                                                                                    // 142
});                                                                                                                    // 133
FlowRouter.route("/pt/:traceId/:appId?", {                                                                             // 145
  action: function () {                                                                                                // 146
    var options = {                                                                                                    // 147
      ignoreLoginCheck: true                                                                                           // 148
    };                                                                                                                 // 147
    BlazeLayout.render("layout.main", {                                                                                // 150
      main: "traceExplorer.shared",                                                                                    // 151
      options: options                                                                                                 // 152
    });                                                                                                                // 150
  }                                                                                                                    // 154
});                                                                                                                    // 145
FlowRouter.route("/et/:traceId/:appId?", {                                                                             // 157
  action: function () {                                                                                                // 158
    var options = {                                                                                                    // 159
      ignoreLoginCheck: true                                                                                           // 160
    };                                                                                                                 // 159
    BlazeLayout.render("layout.main", {                                                                                // 162
      main: "traceExplorer.shared",                                                                                    // 163
      options: options                                                                                                 // 164
    });                                                                                                                // 162
  }                                                                                                                    // 166
});                                                                                                                    // 157
FlowRouter.route("/redirect", {                                                                                        // 169
  name: "redirect",                                                                                                    // 170
  action: function () {                                                                                                // 171
    BlazeLayout.render("layout.redirect");                                                                             // 172
  }                                                                                                                    // 173
});                                                                                                                    // 169
FlowRouter.notFound = {                                                                                                // 176
  action: function () {                                                                                                // 177
    // We've removed "selection" param from the "app" route                                                            // 178
    // So, it's possible to have wrong urls in the localStorage                                                        // 179
    // We need to detect it and fix it                                                                                 // 180
    // XXX we can remove this code sometimes later.                                                                    // 181
    var path = FlowRouter.current().path;                                                                              // 182
    var matched = path.match(/\/apps\/(\w+)\//);                                                                       // 183
                                                                                                                       //
    if (matched) {                                                                                                     // 184
      var appId = matched[1];                                                                                          // 185
      FlowRouter.go("app", {                                                                                           // 186
        appId: appId,                                                                                                  // 187
        section: "dashboard",                                                                                          // 188
        subSection: "overview"                                                                                         // 189
      });                                                                                                              // 186
    }                                                                                                                  // 191
  }                                                                                                                    // 192
};                                                                                                                     // 176
                                                                                                                       //
function checkQueryParam(context) {                                                                                    // 195
  var appId = context.params.appId;                                                                                    // 196
  var section = context.params.section || "dashboard";                                                                 // 197
  var subSection = context.params.subSection || "overview";                                                            // 198
  var params = {                                                                                                       // 199
    "appId": appId,                                                                                                    // 200
    "section": section,                                                                                                // 201
    "subSection": subSection                                                                                           // 202
  };                                                                                                                   // 199
  var path = FlowRouter.path("app", params);                                                                           // 204
  var redirectPath = Meteor.userId() ? path : null;                                                                    // 206
  var plan = Utils.getPlanForTheApp(context.params.appId); // resoultions                                              // 207
                                                                                                                       //
  if (context.queryParams) {                                                                                           // 210
    var range = parseInt(context.queryParams.range) || 60 * 60 * 1000;                                                 // 211
    var maxRange = PlansManager.getConfig("maxRange", plan);                                                           // 212
                                                                                                                       //
    if (range > maxRange) {                                                                                            // 214
      FlowRouter.redirect(redirectPath);                                                                               // 215
    }                                                                                                                  // 216
  } // timejump                                                                                                        // 217
                                                                                                                       //
                                                                                                                       //
  if (context.queryParams && context.queryParams.date) {                                                               // 220
    var allowedRange = PlansManager.getConfig("allowedRange", plan);                                                   // 221
    var date = context.queryParams.date;                                                                               // 222
    var today = moment().valueOf();                                                                                    // 224
    var limit = today - allowedRange;                                                                                  // 225
                                                                                                                       //
    if (date < limit) {                                                                                                // 227
      FlowRouter.redirect(redirectPath);                                                                               // 228
    }                                                                                                                  // 229
  }                                                                                                                    // 230
}                                                                                                                      // 231
                                                                                                                       //
function legacyUrlRedirects(context, redirect) {                                                                       // 233
  var _context$params = context.params,                                                                                // 233
      section = _context$params.section,                                                                               // 233
      subSection = _context$params.subSection; // these are the redirects of URLs we had in the first version of the app
                                                                                                                       //
  if (section === "pubsub" || section === "methods") {                                                                 // 236
    var params = {                                                                                                     // 237
      appId: context.params.appId,                                                                                     // 238
      section: "dashboard",                                                                                            // 239
      subSection: section                                                                                              // 240
    };                                                                                                                 // 237
    redirect("app", params, context.queryParams);                                                                      // 242
  } // redirect if an user visit insights                                                                              // 243
                                                                                                                       //
                                                                                                                       //
  if (section === "insights" && subSection === "summary") {                                                            // 245
    var insightsParams = {                                                                                             // 246
      appId: context.params.appId,                                                                                     // 247
      section: "dashboard",                                                                                            // 248
      subSection: "overview"                                                                                           // 249
    };                                                                                                                 // 246
    redirect("app", insightsParams, context.queryParams);                                                              // 251
  }                                                                                                                    // 252
} // redirect to new profiler if comes from old url                                                                    // 253
                                                                                                                       //
                                                                                                                       //
function redirectToNewProfiler(context, redirect) {                                                                    // 256
  var isOldProfilerUrl = context.params.section === "profiler" && context.params.subSection === "overview";            // 257
                                                                                                                       //
  if (isOldProfilerUrl) {                                                                                              // 260
    var path = "/apps/" + context.params.appId + "/tools/cpu-profiler";                                                // 261
    redirect(path, context.params, context.queryParams);                                                               // 262
  }                                                                                                                    // 263
}                                                                                                                      // 264
                                                                                                                       //
var RESOLUTION_TO_RANGE = {                                                                                            // 266
  "1min": KadiraData.Ranges.getValue("1hour"),                                                                         // 267
  "30min": KadiraData.Ranges.getValue("7day"),                                                                         // 268
  "3hour": KadiraData.Ranges.getValue("1hour")                                                                         // 269
};                                                                                                                     // 266
                                                                                                                       //
function resoultionsToRanges(context, redirect) {                                                                      // 272
  context.queryParams = context.queryParams || {};                                                                     // 273
  var res = context.queryParams.res;                                                                                   // 274
  var range = RESOLUTION_TO_RANGE[res];                                                                                // 275
                                                                                                                       //
  if (range > 0) {                                                                                                     // 276
    var queryParams = _.omit(context.queryParams, "res");                                                              // 277
                                                                                                                       //
    queryParams.range = range;                                                                                         // 278
    redirect("app", context.params, queryParams);                                                                      // 279
  }                                                                                                                    // 280
}                                                                                                                      // 281
                                                                                                                       //
function setTitles() {                                                                                                 // 283
  document.title = "Kadira - Performance Monitoring for Meteor Apps";                                                  // 284
} // currently, this shows us the Kadira Debug app page and                                                            // 285
// then doing the redirect                                                                                             // 288
// With SSR. We'll have a better way to do this.                                                                       // 289
                                                                                                                       //
                                                                                                                       //
function redirectOnKadiraDebug(context, redirect) {                                                                    // 290
  var insideKadiraDebugUrl = /debug\.kadiraio\.com/.test(location.origin);                                             // 291
                                                                                                                       //
  if (insideKadiraDebugUrl && context.route.name !== "debug") {                                                        // 292
    redirect("/redirect");                                                                                             // 293
    location.href = "https://ui.kadira.io" + context.path;                                                             // 294
  }                                                                                                                    // 295
}                                                                                                                      // 296
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/utils.js                                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Utils = {};                                                                                                            // 1
                                                                                                                       //
Utils.prettyDate = function (date) {                                                                                   // 2
  return moment(date).format("dddd, MMM DD, YYYY HH:mm");                                                              // 3
};                                                                                                                     // 4
                                                                                                                       //
Utils.getPlanFromUser = function (user) {                                                                              // 6
  return user.plan || "free";                                                                                          // 7
};                                                                                                                     // 8
                                                                                                                       //
Utils.getPlanForTheApp = function (appId) {                                                                            // 10
  if (!appId) {                                                                                                        // 11
    throw new Meteor.Error("No AppId");                                                                                // 12
  }                                                                                                                    // 13
                                                                                                                       //
  var app = Apps.findOne({                                                                                             // 14
    _id: appId                                                                                                         // 14
  }, {                                                                                                                 // 14
    fields: {                                                                                                          // 14
      plan: 1                                                                                                          // 14
    }                                                                                                                  // 14
  }) || {};                                                                                                            // 14
  return app.plan || "free";                                                                                           // 15
};                                                                                                                     // 16
                                                                                                                       //
Utils.isAdmin = function (user) {                                                                                      // 18
  return !!user.admin;                                                                                                 // 19
};                                                                                                                     // 20
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"validations.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/validations.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/* eslint max-len: 0 */Validations = {};                                                                               // 1
                                                                                                                       //
Validations.checkAppName = function (appName, callback) {                                                              // 4
  var err;                                                                                                             // 5
                                                                                                                       //
  if (!isAlphaNumeric(appName)) {                                                                                      // 6
    err = new Meteor.Error(403, i18n("validations.app_name_validation_failed"));                                       // 7
  }                                                                                                                    // 8
                                                                                                                       //
  if (!(appName && appName.length <= 50)) {                                                                            // 10
    err = new Meteor.Error(403, i18n("validations.app_name_too_long"));                                                // 11
  }                                                                                                                    // 12
                                                                                                                       //
  throwError(err, callback);                                                                                           // 13
};                                                                                                                     // 14
                                                                                                                       //
Validations.checkName = function (name) {                                                                              // 16
  return isAlphaNumeric(name);                                                                                         // 17
};                                                                                                                     // 18
                                                                                                                       //
Validations.checkUrl = function (url, callback) {                                                                      // 20
  var regex = /(http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;                         // 21
  var isValid = regex.test(url);                                                                                       // 22
  var errorString = i18n("validations.url_validation_failed");                                                         // 23
  var err = isValid ? null : new Meteor.Error(403, errorString);                                                       // 24
  throwError(err, callback);                                                                                           // 25
};                                                                                                                     // 26
                                                                                                                       //
Validations.checkEmail = function (email, callback) {                                                                  // 28
  var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  var isValid = regex.test(email);                                                                                     // 30
  var errorString = i18n("validations.email_validation_failed");                                                       // 31
  var err = isValid ? null : new Meteor.Error(403, errorString);                                                       // 32
  throwError(err, callback);                                                                                           // 33
};                                                                                                                     // 34
                                                                                                                       //
Validations.isValidEmailList = function (list) {                                                                       // 36
  var listArr = list.split("\n");                                                                                      // 37
  var retVal = true;                                                                                                   // 38
                                                                                                                       //
  for (var i = 0; i < listArr.length; i++) {                                                                           // 39
    var email = $.trim(listArr[i]);                                                                                    // 40
                                                                                                                       //
    if (!isValidEmail(email)) {                                                                                        // 41
      retVal = false;                                                                                                  // 42
    }                                                                                                                  // 43
  }                                                                                                                    // 44
                                                                                                                       //
  return retVal;                                                                                                       // 45
};                                                                                                                     // 46
                                                                                                                       //
Validations.isValidUrllList = function (list) {                                                                        // 48
  var listArr = list.split("\n");                                                                                      // 49
  var retVal = true;                                                                                                   // 50
                                                                                                                       //
  for (var i = 0; i < listArr.length; i++) {                                                                           // 51
    var url = $.trim(listArr[i]);                                                                                      // 52
                                                                                                                       //
    if (!isValidUrl(url)) {                                                                                            // 53
      retVal = false;                                                                                                  // 54
    }                                                                                                                  // 55
  }                                                                                                                    // 56
                                                                                                                       //
  return retVal;                                                                                                       // 57
};                                                                                                                     // 58
                                                                                                                       //
function isValidEmail(email) {                                                                                         // 60
  var regExp = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;                   // 61
  return regExp.test(email);                                                                                           // 62
}                                                                                                                      // 63
                                                                                                                       //
function isValidUrl(url) {                                                                                             // 65
  var regExp = /(http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;                        // 66
  return regExp.test(url);                                                                                             // 67
}                                                                                                                      // 68
                                                                                                                       //
function isAlphaNumeric(string) {                                                                                      // 70
  var regex = /^[a-zA-Z0-9\-\s]+$/;                                                                                    // 71
  return regex.test(string);                                                                                           // 72
}                                                                                                                      // 73
                                                                                                                       //
function throwError(error, callback) {                                                                                 // 75
  if (Meteor.isServer && error) {                                                                                      // 76
    throw error;                                                                                                       // 77
  } else if (Meteor.isClient) {                                                                                        // 78
    var result = error ? false : true;                                                                                 // 79
    callback(error, result);                                                                                           // 80
  }                                                                                                                    // 81
}                                                                                                                      // 82
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"kadira_data_definitions":{"filters":{"0filters.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/filters/0filters.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var zlib = Npm.require("zlib");                                                                                        // 1
                                                                                                                       //
KadiraDataFilters = {};                                                                                                // 3
                                                                                                                       //
KadiraDataFilters.rateFilterForBreakdown = function (rateFields) {                                                     // 5
  var rateFieldsMap = {};                                                                                              // 7
  rateFields.forEach(function (field) {                                                                                // 8
    rateFieldsMap[field] = true;                                                                                       // 9
  });                                                                                                                  // 10
  return function (data, args) {                                                                                       // 12
    var divideAmount = rangeToMinutes(args.range);                                                                     // 13
    return data.map(function (item) {                                                                                  // 14
      if (rateFieldsMap[args.sortBy]) {                                                                                // 15
        item.sortedValue /= divideAmount;                                                                              // 16
      } // common value is a throughput metric always                                                                  // 17
      // so, we need to devide it always                                                                               // 20
                                                                                                                       //
                                                                                                                       //
      item.commonValue /= divideAmount;                                                                                // 21
      return item;                                                                                                     // 22
    });                                                                                                                // 23
  };                                                                                                                   // 24
};                                                                                                                     // 25
                                                                                                                       //
KadiraDataFilters.rateFilterForCharts = function (rateFields) {                                                        // 27
  return function (data, args) {                                                                                       // 29
    var resolution = args.query["value.res"];                                                                          // 30
    var divideAmount = getTimeInterval(resolution) / (1000 * 60);                                                      // 32
    return data.map(function (item) {                                                                                  // 33
      rateFields.forEach(function (field) {                                                                            // 34
        if (item[field]) {                                                                                             // 35
          item[field] /= divideAmount;                                                                                 // 36
        }                                                                                                              // 37
      });                                                                                                              // 38
      return item;                                                                                                     // 39
    });                                                                                                                // 40
  };                                                                                                                   // 41
};                                                                                                                     // 42
                                                                                                                       //
KadiraDataFilters.divideByRange = function (divideFields) {                                                            // 44
  return function (data, args) {                                                                                       // 46
    var divideAmount = rangeToMinutes(args.range);                                                                     // 47
    return data.map(function (item) {                                                                                  // 48
      divideFields.forEach(function (field) {                                                                          // 49
        if (item[field]) {                                                                                             // 50
          item[field] /= divideAmount;                                                                                 // 51
        }                                                                                                              // 52
      });                                                                                                              // 53
      return item;                                                                                                     // 54
    });                                                                                                                // 55
  };                                                                                                                   // 56
};                                                                                                                     // 57
                                                                                                                       //
KadiraDataFilters.roundTo = function (keys, decimalPoints) {                                                           // 60
  if (!(keys instanceof Array)) {                                                                                      // 61
    keys = [keys];                                                                                                     // 62
  }                                                                                                                    // 63
                                                                                                                       //
  return function (data) {                                                                                             // 65
    return data.map(function (item) {                                                                                  // 66
      keys.forEach(function (key) {                                                                                    // 67
        if (item[key]) {                                                                                               // 68
          item[key] = parseFloat(item[key].toFixed(decimalPoints));                                                    // 69
        }                                                                                                              // 70
      });                                                                                                              // 71
      return item;                                                                                                     // 72
    });                                                                                                                // 73
  };                                                                                                                   // 74
};                                                                                                                     // 75
                                                                                                                       //
KadiraDataFilters.toPct = function (decimalPoints) {                                                                   // 77
  return function (data) {                                                                                             // 78
    return data.map(function (item) {                                                                                  // 79
      item.pcpu = parseFloat(item.pcpu.toFixed(decimalPoints));                                                        // 80
      return item;                                                                                                     // 81
    });                                                                                                                // 82
  };                                                                                                                   // 83
};                                                                                                                     // 84
                                                                                                                       //
KadiraDataFilters.decriptTrace = function () {                                                                         // 86
  function decriptTrace(data) {                                                                                        // 86
    var decriptedData = data.map(function (item) {                                                                     // 87
      if (item.compressed) {                                                                                           // 88
        return Meteor.wrapAsync(_unzipTrace)(item);                                                                    // 89
      } else {                                                                                                         // 90
        return item;                                                                                                   // 91
      }                                                                                                                // 92
    });                                                                                                                // 93
    return decriptedData;                                                                                              // 95
  }                                                                                                                    // 96
                                                                                                                       //
  return decriptTrace;                                                                                                 // 86
}();                                                                                                                   // 86
                                                                                                                       //
function _unzipTrace(trace, callback) {                                                                                // 98
  zlib.unzip(trace.events.value(true), function (err, eventJsonString) {                                               // 99
    if (err) {                                                                                                         // 100
      callback(err);                                                                                                   // 101
    } else {                                                                                                           // 102
      var events = JSON.parse(eventJsonString.toString()); // converting at dataString to date object                  // 103
      // while at the compression, date object will became a date string                                               // 105
                                                                                                                       //
      trace.events = events.map(function (e) {                                                                         // 106
        if (e.at) {                                                                                                    // 107
          e.at = new Date(e.at);                                                                                       // 108
        }                                                                                                              // 109
                                                                                                                       //
        return e;                                                                                                      // 110
      });                                                                                                              // 111
      delete trace.compressed;                                                                                         // 112
      callback(null, trace);                                                                                           // 113
    }                                                                                                                  // 114
  });                                                                                                                  // 115
}                                                                                                                      // 116
                                                                                                                       //
KadiraDataFilters.addZeros = function (metrics) {                                                                      // 118
  return function (data, args) {                                                                                       // 119
    var query = args.query;                                                                                            // 120
    var startTime = new Date(query["value.startTime"]["$gte"]).getTime();                                              // 121
    var endTime = new Date(query["value.startTime"]["$lt"]).getTime();                                                 // 122
    var resolution = query["value.res"];                                                                               // 123
    var timeInterval = getTimeInterval(resolution);                                                                    // 124
    var expectedCount = Math.round((endTime - startTime) / timeInterval);                                              // 125
    var newData = [];                                                                                                  // 126
                                                                                                                       //
    if (args.groupByHost) {                                                                                            // 127
      var hostsData = getHostsData(data);                                                                              // 128
      var newHostsData = {};                                                                                           // 129
                                                                                                                       //
      for (var host in meteorBabelHelpers.sanitizeForInObject(hostsData)) {                                            // 130
        newHostsData[host] = [];                                                                                       // 131
        var mhPointsArgs = {                                                                                           // 133
          metrics: metrics,                                                                                            // 134
          timeInterval: timeInterval,                                                                                  // 135
          host: host                                                                                                   // 136
        };                                                                                                             // 133
        fillMiddlePoints(hostsData[host], newHostsData[host], mhPointsArgs);                                           // 138
        var fhPointsArgs = {                                                                                           // 140
          metrics: metrics,                                                                                            // 141
          timeInterval: timeInterval,                                                                                  // 142
          startTime: startTime,                                                                                        // 143
          expectedCount: expectedCount,                                                                                // 144
          host: host                                                                                                   // 145
        };                                                                                                             // 140
        fillFrontPoints(hostsData[host], newHostsData[host], fhPointsArgs);                                            // 147
        var ehPointsArgs = {                                                                                           // 149
          metrics: metrics,                                                                                            // 150
          timeInterval: timeInterval,                                                                                  // 151
          endTime: endTime,                                                                                            // 152
          host: host                                                                                                   // 153
        };                                                                                                             // 149
        fillEndPoints(hostsData[host], newHostsData[host], ehPointsArgs);                                              // 155
      }                                                                                                                // 156
                                                                                                                       //
      var unSortedHostsData = _.flatten(_.values(newHostsData), true);                                                 // 158
                                                                                                                       //
      newData = _.sortBy(unSortedHostsData, function (d) {                                                             // 159
        return d._id.time.getTime();                                                                                   // 160
      });                                                                                                              // 161
    } else {                                                                                                           // 162
      var mPointsArgs = {                                                                                              // 163
        metrics: metrics,                                                                                              // 164
        timeInterval: timeInterval                                                                                     // 165
      };                                                                                                               // 163
      fillMiddlePoints(data, newData, mPointsArgs);                                                                    // 167
      var fPointsArgs = {                                                                                              // 169
        metrics: metrics,                                                                                              // 170
        timeInterval: timeInterval,                                                                                    // 171
        startTime: startTime,                                                                                          // 172
        expectedCount: expectedCount                                                                                   // 173
      };                                                                                                               // 169
      fillFrontPoints(data, newData, fPointsArgs);                                                                     // 175
      var ePointsArgs = {                                                                                              // 177
        metrics: metrics,                                                                                              // 178
        timeInterval: timeInterval,                                                                                    // 179
        endTime: endTime                                                                                               // 180
      };                                                                                                               // 177
      fillEndPoints(data, newData, ePointsArgs);                                                                       // 182
    }                                                                                                                  // 183
                                                                                                                       //
    return newData;                                                                                                    // 185
  };                                                                                                                   // 187
};                                                                                                                     // 188
                                                                                                                       //
KadiraDataFilters._addZeroPoints = function (newData, args) {                                                          // 190
  args.timeDiff = args.addtoFront ? -args.timeDiff : args.timeDiff;                                                    // 191
                                                                                                                       //
  for (var j = 1; j <= args.zeroPointsCount; j++) {                                                                    // 192
    var newPointTime = new Date(args.timeStamp + args.timeDiff * j);                                                   // 193
    var point = {                                                                                                      // 194
      _id: {                                                                                                           // 194
        time: newPointTime                                                                                             // 194
      }                                                                                                                // 194
    };                                                                                                                 // 194
                                                                                                                       //
    if (args.host) {                                                                                                   // 195
      point._id.host = args.host;                                                                                      // 196
    } /* jshint ignore:start */                                                                                        // 197
                                                                                                                       //
    args.metrics.forEach(function (metric) {                                                                           // 200
      point[metric] = 0;                                                                                               // 201
    }); /* jshint ignore:end */                                                                                        // 202
                                                                                                                       //
    if (args.addtoFront) {                                                                                             // 206
      newData.unshift(point);                                                                                          // 207
    } else {                                                                                                           // 208
      newData.push(point);                                                                                             // 209
    }                                                                                                                  // 210
  }                                                                                                                    // 211
                                                                                                                       //
  return newData;                                                                                                      // 212
};                                                                                                                     // 213
                                                                                                                       //
function getHostsData(data) {                                                                                          // 215
  var hostsData = {};                                                                                                  // 216
  data.forEach(function (d) {                                                                                          // 218
    var host = d._id.host;                                                                                             // 219
                                                                                                                       //
    if (host) {                                                                                                        // 220
      hostsData[host] = hostsData[host] || [];                                                                         // 221
      hostsData[host].push(d);                                                                                         // 222
    }                                                                                                                  // 223
  });                                                                                                                  // 224
  return hostsData;                                                                                                    // 225
}                                                                                                                      // 226
                                                                                                                       //
function getTimeInterval(resolution) {                                                                                 // 228
  var INTERVALS = {                                                                                                    // 229
    "1min": 1 * 60 * 1000,                                                                                             // 230
    "30min": 30 * 60 * 1000,                                                                                           // 231
    "3hour": 3 * 3600 * 1000                                                                                           // 232
  };                                                                                                                   // 229
  return INTERVALS[resolution];                                                                                        // 234
}                                                                                                                      // 235
                                                                                                                       //
function fillMiddlePoints(data, newData, args) {                                                                       // 237
  for (var i = 0; i < data.length; i++) {                                                                              // 238
    newData.push(data[i]);                                                                                             // 239
    var j = i + 1;                                                                                                     // 240
                                                                                                                       //
    if (j < data.length) {                                                                                             // 241
      var timeStamp = data[i]._id.time.getTime();                                                                      // 242
                                                                                                                       //
      var pointTimeDiff = data[i + 1]._id.time.getTime() - timeStamp;                                                  // 243
      var zeroMPointsCount = Math.floor(pointTimeDiff / args.timeInterval) - 1;                                        // 244
      var zeroPointArgs = {                                                                                            // 246
        metrics: args.metrics,                                                                                         // 247
        timeStamp: timeStamp,                                                                                          // 248
        timeDiff: args.timeInterval,                                                                                   // 249
        zeroPointsCount: zeroMPointsCount,                                                                             // 250
        host: args.host                                                                                                // 251
      };                                                                                                               // 246
                                                                                                                       //
      KadiraDataFilters._addZeroPoints(newData, zeroPointArgs);                                                        // 253
    }                                                                                                                  // 254
  }                                                                                                                    // 255
}                                                                                                                      // 256
                                                                                                                       //
function fillFrontPoints(data, newData, args) {                                                                        // 258
  var firstPoint = data[0];                                                                                            // 259
                                                                                                                       //
  if (!firstPoint) {                                                                                                   // 260
    // empty data array                                                                                                // 260
    //addZeroPoints ignores first point, so push back start time                                                       // 261
    var pointsStartTime = args.startTime - args.timeInterval;                                                          // 262
    var emptyZeroPointArgs = {                                                                                         // 263
      metrics: args.metrics,                                                                                           // 264
      timeStamp: pointsStartTime,                                                                                      // 265
      timeDiff: args.timeInterval,                                                                                     // 266
      zeroPointsCount: args.expectedCount,                                                                             // 267
      host: args.host                                                                                                  // 268
    };                                                                                                                 // 263
                                                                                                                       //
    KadiraDataFilters._addZeroPoints(newData, emptyZeroPointArgs);                                                     // 270
  } else {                                                                                                             // 271
    var firstPointTime = data[0]._id.time.getTime();                                                                   // 272
                                                                                                                       //
    var zeroFPointsCount = Math.floor((firstPointTime - args.startTime) / args.timeInterval);                          // 273
    var zeroPointArgs = {                                                                                              // 275
      metrics: args.metrics,                                                                                           // 276
      timeStamp: firstPointTime,                                                                                       // 277
      timeDiff: args.timeInterval,                                                                                     // 278
      zeroPointsCount: zeroFPointsCount,                                                                               // 279
      host: args.host,                                                                                                 // 280
      addtoFront: true                                                                                                 // 281
    };                                                                                                                 // 275
                                                                                                                       //
    KadiraDataFilters._addZeroPoints(newData, zeroPointArgs);                                                          // 284
  }                                                                                                                    // 285
}                                                                                                                      // 286
                                                                                                                       //
function fillEndPoints(data, newData, args) {                                                                          // 288
  var lastPoint = data[data.length - 1];                                                                               // 289
                                                                                                                       //
  if (lastPoint) {                                                                                                     // 290
    var lastPointTime = lastPoint._id.time.getTime();                                                                  // 291
                                                                                                                       //
    var zeroEPointsCount = Math.floor((args.endTime - lastPointTime) / args.timeInterval);                             // 292
    var zeroPointArgs = {                                                                                              // 294
      metrics: args.metrics,                                                                                           // 295
      timeStamp: lastPointTime,                                                                                        // 296
      timeDiff: args.timeInterval,                                                                                     // 297
      zeroPointsCount: zeroEPointsCount - 1,                                                                           // 298
      host: args.host                                                                                                  // 299
    };                                                                                                                 // 294
                                                                                                                       //
    KadiraDataFilters._addZeroPoints(newData, zeroPointArgs);                                                          // 301
  }                                                                                                                    // 302
}                                                                                                                      // 303
                                                                                                                       //
KadiraDataFilters.convertObjectToId = function (data) {                                                                // 305
  data.forEach(function (d) {                                                                                          // 306
    d._id = Random.id();                                                                                               // 307
  });                                                                                                                  // 308
  return data;                                                                                                         // 309
};                                                                                                                     // 310
                                                                                                                       //
KadiraDataFilters.limitSamples = function (limit) {                                                                    // 312
  return function (data) {                                                                                             // 313
    data.forEach(function (d) {                                                                                        // 314
      d.samples.splice(limit);                                                                                         // 315
    });                                                                                                                // 316
    return data;                                                                                                       // 317
  };                                                                                                                   // 318
};                                                                                                                     // 319
                                                                                                                       //
function rangeToMinutes(range) {                                                                                       // 321
  return range / (60 * 1000);                                                                                          // 322
}                                                                                                                      // 323
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"errorManager.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/filters/errorManager.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraErrorFilters = {};                                                                                               // 1
                                                                                                                       //
KadiraErrorFilters.filterErrorsByStatus = function () {                                                                // 2
  return function (data, args) {                                                                                       // 3
    var showIgnored = KadiraErrorFilters._canShowIgnored(args);                                                        // 4
                                                                                                                       //
    var status = args.status;                                                                                          // 5
                                                                                                                       //
    if (args.status === "all") {                                                                                       // 6
      status = false;                                                                                                  // 7
    }                                                                                                                  // 8
                                                                                                                       //
    var appId = args.appId;                                                                                            // 9
                                                                                                                       //
    var filteredErrorsMeta = KadiraErrorFilters._getErrorsMeta(data, appId);                                           // 10
                                                                                                                       //
    if (status) {                                                                                                      // 11
      var newData = KadiraErrorFilters._includeByStatus(data, filteredErrorsMeta, status);                             // 12
                                                                                                                       //
      return newData;                                                                                                  // 14
    }                                                                                                                  // 15
                                                                                                                       //
    if (showIgnored) {                                                                                                 // 17
      return KadiraErrorFilters._getAllErrors(data, filteredErrorsMeta);                                               // 18
    } else {                                                                                                           // 19
      var filteredIgnored = KadiraErrorFilters._excludeByStatus(data, filteredErrorsMeta, "ignored");                  // 20
                                                                                                                       //
      return filteredIgnored;                                                                                          // 22
    }                                                                                                                  // 23
  };                                                                                                                   // 24
};                                                                                                                     // 26
                                                                                                                       //
KadiraErrorFilters._getErrorsMeta = function () {                                                                      // 28
  function getErrorsMeta(data, appId) {                                                                                // 28
    var query = {};                                                                                                    // 29
    query.appId = {                                                                                                    // 30
      $in: appId                                                                                                       // 30
    };                                                                                                                 // 30
                                                                                                                       //
    if (data.length > 0) {                                                                                             // 31
      query["$or"] = [];                                                                                               // 32
      data.forEach(function (d) {                                                                                      // 33
        query["$or"].push({                                                                                            // 34
          "name": d._id.name,                                                                                          // 34
          "type": d._id.type                                                                                           // 34
        });                                                                                                            // 34
      });                                                                                                              // 35
    }                                                                                                                  // 36
                                                                                                                       //
    var fields = {                                                                                                     // 37
      fields: {                                                                                                        // 37
        name: 1,                                                                                                       // 37
        status: 1,                                                                                                     // 37
        type: 1                                                                                                        // 37
      }                                                                                                                // 37
    };                                                                                                                 // 37
    var errorsMeta = ErrorsMeta.find(query, fields).fetch();                                                           // 38
    var filteredErrorsMetaMap = {};                                                                                    // 40
    errorsMeta.forEach(function (m) {                                                                                  // 41
      filteredErrorsMetaMap[m.name + m.type] = m;                                                                      // 42
    });                                                                                                                // 43
    return filteredErrorsMetaMap;                                                                                      // 44
  }                                                                                                                    // 45
                                                                                                                       //
  return getErrorsMeta;                                                                                                // 28
}();                                                                                                                   // 28
                                                                                                                       //
KadiraErrorFilters._getAllErrors = function () {                                                                       // 47
  function getAllErrors(data, filteredErrorsMetaMap) {                                                                 // 48
    var newData = [];                                                                                                  // 49
    data.forEach(function (d) {                                                                                        // 51
      var found = filteredErrorsMetaMap[d._id.name + d._id.type];                                                      // 52
      d = KadiraErrorFilters._setStatusForError(found, d);                                                             // 53
      newData.push(d);                                                                                                 // 54
    });                                                                                                                // 55
    return newData;                                                                                                    // 56
  }                                                                                                                    // 57
                                                                                                                       //
  return getAllErrors;                                                                                                 // 47
}();                                                                                                                   // 47
                                                                                                                       //
KadiraErrorFilters._includeByStatus = function () {                                                                    // 59
  function includeByStatus(data, filteredErrorsMetaMap, status) {                                                      // 60
    var newData = [];                                                                                                  // 61
    data.forEach(function (d) {                                                                                        // 62
      var found = filteredErrorsMetaMap[d._id.name + d._id.type];                                                      // 63
      d = KadiraErrorFilters._setStatusForError(found, d);                                                             // 64
                                                                                                                       //
      if (d.status === status) {                                                                                       // 65
        newData.push(d);                                                                                               // 66
      }                                                                                                                // 67
    });                                                                                                                // 68
    return newData;                                                                                                    // 69
  }                                                                                                                    // 70
                                                                                                                       //
  return includeByStatus;                                                                                              // 59
}();                                                                                                                   // 59
                                                                                                                       //
KadiraErrorFilters._excludeByStatus = function () {                                                                    // 72
  function excludeByStatus(data, filteredErrorsMetaMap, status) {                                                      // 73
    var newData = [];                                                                                                  // 74
    data.forEach(function (d) {                                                                                        // 75
      var found = filteredErrorsMetaMap[d._id.name + d._id.type];                                                      // 76
      d = KadiraErrorFilters._setStatusForError(found, d);                                                             // 77
                                                                                                                       //
      if (d.status !== status) {                                                                                       // 78
        newData.push(d);                                                                                               // 79
      }                                                                                                                // 80
    });                                                                                                                // 81
    return newData;                                                                                                    // 82
  }                                                                                                                    // 83
                                                                                                                       //
  return excludeByStatus;                                                                                              // 72
}();                                                                                                                   // 72
                                                                                                                       //
KadiraErrorFilters._canShowIgnored = function () {                                                                     // 85
  function canShowIgnored(args) {                                                                                      // 86
    var status = args.status; // if status is ignored we must show ignored errors                                      // 87
                                                                                                                       //
    if (status === "ignored") {                                                                                        // 89
      return true;                                                                                                     // 90
    } //only look at status arg if it is "all"                                                                         // 91
                                                                                                                       //
                                                                                                                       //
    if (status === "all") {                                                                                            // 93
      return args.showIgnored;                                                                                         // 94
    }                                                                                                                  // 95
                                                                                                                       //
    return false;                                                                                                      // 96
  }                                                                                                                    // 97
                                                                                                                       //
  return canShowIgnored;                                                                                               // 85
}();                                                                                                                   // 85
                                                                                                                       //
KadiraErrorFilters._setStatusForError = function () {                                                                  // 99
  function setStatusForError(found, error) {                                                                           // 100
    if (found) {                                                                                                       // 101
      error.status = found.status;                                                                                     // 102
    } else {                                                                                                           // 103
      error.status = "new";                                                                                            // 104
    }                                                                                                                  // 105
                                                                                                                       //
    return error;                                                                                                      // 106
  }                                                                                                                    // 107
                                                                                                                       //
  return setStatusForError;                                                                                            // 99
}();                                                                                                                   // 99
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"0helpers.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/0helpers.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraDataHelpers = {};                                                                                                // 1
                                                                                                                       //
KadiraDataHelpers.divideWithZero = function (val1, val2, ignoreZeros) {                                                // 3
  if (ignoreZeros) {                                                                                                   // 4
    val1 = {                                                                                                           // 5
      $cond: [{                                                                                                        // 5
        $eq: [val2, 0]                                                                                                 // 5
      }, 0, val1]                                                                                                      // 5
    };                                                                                                                 // 5
  }                                                                                                                    // 6
                                                                                                                       //
  return {                                                                                                             // 8
    $divide: [val1, {                                                                                                  // 8
      $cond: [{                                                                                                        // 10
        $eq: [val2, 0]                                                                                                 // 10
      }, 1, val2]                                                                                                      // 10
    }]                                                                                                                 // 10
  };                                                                                                                   // 8
};                                                                                                                     // 12
                                                                                                                       //
KadiraDataHelpers.safeMultiply = function (a, b) {                                                                     // 14
  var aIfNull = {                                                                                                      // 15
    $cond: [{                                                                                                          // 15
      $gt: [a, 0]                                                                                                      // 15
    }, a, 0]                                                                                                           // 15
  };                                                                                                                   // 15
  var bIfNull = {                                                                                                      // 16
    $cond: [{                                                                                                          // 16
      $gt: [b, 0]                                                                                                      // 16
    }, b, 0]                                                                                                           // 16
  };                                                                                                                   // 16
  return {                                                                                                             // 18
    $multiply: [aIfNull, bIfNull]                                                                                      // 18
  };                                                                                                                   // 18
};                                                                                                                     // 19
                                                                                                                       //
KadiraDataHelpers.removeExpireFlag = function (collection, appId, traceId) {                                           // 21
  var appId = appId ? appId[0] : null;                                                                                 // 22
  var dbConn;                                                                                                          // 23
                                                                                                                       //
  if (!appId) {                                                                                                        // 24
    dbConn = KadiraData.mongoCluster.getConnection("one");                                                             // 25
  } else {                                                                                                             // 26
    dbConn = KadiraData.getConnectionForApp(appId);                                                                    // 27
  }                                                                                                                    // 28
                                                                                                                       //
  var coll = dbConn.collection(collection);                                                                            // 29
  coll.update({                                                                                                        // 30
    _id: traceId                                                                                                       // 30
  }, {                                                                                                                 // 30
    $unset: {                                                                                                          // 30
      _expires: 1                                                                                                      // 30
    }                                                                                                                  // 30
  }, function () {});                                                                                                  // 30
};                                                                                                                     // 32
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dashboard.hosts.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/dashboard.hosts.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("hosts", "systemMetrics", function (args) {                                                   // 1
  var query = args.query;                                                                                              // 2
  delete query["value.host"];                                                                                          // 3
  var pipes = [];                                                                                                      // 5
  pipes.push({                                                                                                         // 6
    $match: query                                                                                                      // 6
  });                                                                                                                  // 6
  pipes.push({                                                                                                         // 7
    $group: buildGroup()                                                                                               // 7
  });                                                                                                                  // 7
  pipes.push({                                                                                                         // 8
    $sort: {                                                                                                           // 8
      _id: 1                                                                                                           // 8
    }                                                                                                                  // 8
  });                                                                                                                  // 8
  return pipes;                                                                                                        // 9
                                                                                                                       //
  function buildGroup() {                                                                                              // 11
    var groupDef = {                                                                                                   // 12
      _id: "$value.host",                                                                                              // 13
      count: {                                                                                                         // 14
        $sum: 1                                                                                                        // 14
      }                                                                                                                // 14
    };                                                                                                                 // 12
    return groupDef;                                                                                                   // 16
  }                                                                                                                    // 17
});                                                                                                                    // 18
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dashboard.live_queries.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/dashboard.live_queries.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("breakdown.liveQueries", "pubMetrics", function (args) {                                      // 1
  var query = args.query;                                                                                              // 2
  var pipes = [];                                                                                                      // 3
  var projectDef = {};                                                                                                 // 4
  var groupDef = {};                                                                                                   // 5
  var sortDef = {                                                                                                      // 6
    "sortedValue": -1                                                                                                  // 6
  };                                                                                                                   // 6
  pipes.push({                                                                                                         // 7
    $match: query                                                                                                      // 7
  });                                                                                                                  // 7
  pipes.push({                                                                                                         // 8
    $group: groupDef                                                                                                   // 8
  });                                                                                                                  // 8
  pipes.push({                                                                                                         // 9
    $project: projectDef                                                                                               // 9
  });                                                                                                                  // 9
  pipes.push({                                                                                                         // 10
    $sort: sortDef                                                                                                     // 10
  });                                                                                                                  // 10
  pipes.push({                                                                                                         // 11
    $limit: 50                                                                                                         // 11
  }); // build group                                                                                                   // 11
                                                                                                                       //
  groupDef._id = "$value.pub";                                                                                         // 14
  groupDef.commonValue = {                                                                                             // 15
    "$sum": "$value.subs"                                                                                              // 15
  }; // build project                                                                                                  // 15
                                                                                                                       //
  projectDef.commonValue = "$commonValue";                                                                             // 18
  projectDef.sortValueTitle = "$_id";                                                                                  // 19
  projectDef.id = "$_id";                                                                                              // 20
                                                                                                                       //
  switch (args.sortBy) {                                                                                               // 22
    case "subs":                                                                                                       // 23
    case "polledDocuments":                                                                                            // 24
    case "initiallyAddedDocuments":                                                                                    // 25
    case "liveAddedDocuments":                                                                                         // 26
    case "liveChangedDocuments":                                                                                       // 27
    case "liveRemovedDocuments":                                                                                       // 28
      groupDef.sortedValue = {                                                                                         // 29
        "$sum": "$value." + args.sortBy                                                                                // 29
      };                                                                                                               // 29
      projectDef.sortedValue = "$sortedValue";                                                                         // 30
      break;                                                                                                           // 31
                                                                                                                       //
    case "totalObserverChanges":                                                                                       // 32
      var fields = ["$value.initiallyAddedDocuments", "$value.liveAddedDocuments", "$value.liveChangedDocuments", "$value.liveRemovedDocuments"];
      groupDef.sortedValue = {                                                                                         // 39
        "$sum": {                                                                                                      // 39
          $add: fields                                                                                                 // 39
        }                                                                                                              // 39
      };                                                                                                               // 39
      projectDef.sortedValue = "$sortedValue";                                                                         // 40
      break;                                                                                                           // 41
                                                                                                                       //
    case "totalLiveUpdates":                                                                                           // 42
      var fields = ["$value.liveAddedDocuments", "$value.liveChangedDocuments", "$value.liveRemovedDocuments"];        // 43
      groupDef.sortedValue = {                                                                                         // 48
        "$sum": {                                                                                                      // 48
          $add: fields                                                                                                 // 48
        }                                                                                                              // 48
      };                                                                                                               // 48
      projectDef.sortedValue = "$sortedValue";                                                                         // 49
      break;                                                                                                           // 50
                                                                                                                       //
    case "oplogNotifications":                                                                                         // 51
      var fields = ["$value.oplogDeletedDocuments", "$value.oplogUpdatedDocuments", "$value.oplogInsertedDocuments"];  // 52
      groupDef.sortedValue = {                                                                                         // 57
        "$sum": {                                                                                                      // 57
          $add: fields                                                                                                 // 57
        }                                                                                                              // 57
      };                                                                                                               // 57
      projectDef.sortedValue = "$sortedValue";                                                                         // 58
      break;                                                                                                           // 59
                                                                                                                       //
    case "updateRatio.low":                                                                                            // 60
    case "updateRatio.high":                                                                                           // 61
      groupDef.initiallyAddedDocuments = {                                                                             // 62
        "$sum": "$value.initiallyAddedDocuments"                                                                       // 63
      };                                                                                                               // 62
      var allDocumentChangesFields = ["$value.liveAddedDocuments", "$value.liveChangedDocuments", "$value.liveRemovedDocuments"];
      groupDef.allDocumentChanges = {                                                                                  // 69
        "$sum": {                                                                                                      // 69
          $add: allDocumentChangesFields                                                                               // 69
        }                                                                                                              // 69
      };                                                                                                               // 69
      projectDef.sortedValue = KadiraDataHelpers.safeMultiply(KadiraDataHelpers.divideWithZero("$allDocumentChanges", "$initiallyAddedDocuments", true), 100);
      sortDef.sortedValue = args.sortBy === "updateRatio.low" ? 1 : -1;                                                // 77
      break;                                                                                                           // 78
                                                                                                                       //
    case "observerReuse.low":                                                                                          // 79
    case "observerReuse.high":                                                                                         // 80
      groupDef.totalObserverHandlers = {                                                                               // 81
        "$sum": "$value.totalObserverHandlers"                                                                         // 81
      };                                                                                                               // 81
      groupDef.cachedObservers = {                                                                                     // 82
        "$sum": "$value.cachedObservers"                                                                               // 82
      };                                                                                                               // 82
      projectDef.sortedValue = KadiraDataHelpers.safeMultiply(KadiraDataHelpers.divideWithZero("$cachedObservers", "$totalObserverHandlers"), 100);
      sortDef.sortedValue = args.sortBy === "observerReuse.low" ? 1 : -1;                                              // 89
      break;                                                                                                           // 90
  }                                                                                                                    // 22
                                                                                                                       //
  return pipes;                                                                                                        // 93
}, [KadiraDataFilters.rateFilterForBreakdown(["subs"]), KadiraDataFilters.roundTo(["commonValue"], 2)]);               // 94
KadiraData.defineMetrics("timeseries.activeSubsLifeTime", "pubMetrics", function (args) {                              // 99
  var query = args.query;                                                                                              // 102
  var selectedPublication = args.selection;                                                                            // 104
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 105
    query["value.pub"] = selectedPublication;                                                                          // 106
  }                                                                                                                    // 107
                                                                                                                       //
  var pipes = [];                                                                                                      // 108
  pipes.push({                                                                                                         // 109
    $match: query                                                                                                      // 109
  });                                                                                                                  // 109
  pipes.push({                                                                                                         // 110
    $group: buildGroup()                                                                                               // 110
  });                                                                                                                  // 110
  pipes.push({                                                                                                         // 111
    $group: buildPostGroup()                                                                                           // 111
  });                                                                                                                  // 111
  pipes.push({                                                                                                         // 112
    $project: {                                                                                                        // 112
      _id: "$_id",                                                                                                     // 113
      activeSubs: "$activeSubs"                                                                                        // 114
    }                                                                                                                  // 112
  });                                                                                                                  // 112
  pipes.push({                                                                                                         // 116
    $sort: {                                                                                                           // 116
      _id: 1                                                                                                           // 116
    }                                                                                                                  // 116
  });                                                                                                                  // 116
                                                                                                                       //
  function buildGroup() {                                                                                              // 118
    var groupId = {                                                                                                    // 119
      time: "$value.startTime",                                                                                        // 120
      host: "$value.host",                                                                                             // 121
      pub: "$value.pub"                                                                                                // 122
    };                                                                                                                 // 119
    var groupDef = {                                                                                                   // 124
      _id: groupId                                                                                                     // 124
    };                                                                                                                 // 124
    groupDef.activeSubs = {                                                                                            // 126
      "$avg": "$value.activeSubs"                                                                                      // 126
    };                                                                                                                 // 126
    return groupDef;                                                                                                   // 127
  }                                                                                                                    // 128
                                                                                                                       //
  function buildPostGroup() {                                                                                          // 130
    var groupDef = {                                                                                                   // 131
      _id: {                                                                                                           // 131
        time: "$_id.time"                                                                                              // 131
      }                                                                                                                // 131
    };                                                                                                                 // 131
    groupDef.activeSubs = {                                                                                            // 133
      "$sum": "$activeSubs"                                                                                            // 133
    };                                                                                                                 // 133
    return groupDef;                                                                                                   // 134
  }                                                                                                                    // 135
                                                                                                                       //
  return pipes;                                                                                                        // 137
}, [KadiraDataFilters.roundTo(["activeSubs"], 2), KadiraDataFilters.addZeros(["activeSubs"])]);                        // 139
KadiraData.defineMetrics("timeseries.documentsChangedCount", "pubMetrics", function (args) {                           // 144
  var groupByHost = args.groupByHost;                                                                                  // 146
  var query = args.query;                                                                                              // 147
  var selectedPublication = args.selection;                                                                            // 149
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 150
    query["value.pub"] = selectedPublication;                                                                          // 151
  }                                                                                                                    // 152
                                                                                                                       //
  var pipes = [];                                                                                                      // 154
  pipes.push({                                                                                                         // 155
    $match: query                                                                                                      // 155
  });                                                                                                                  // 155
  pipes.push({                                                                                                         // 156
    $group: buildGroup()                                                                                               // 156
  });                                                                                                                  // 156
  pipes.push({                                                                                                         // 158
    $sort: {                                                                                                           // 158
      _id: 1                                                                                                           // 158
    }                                                                                                                  // 158
  });                                                                                                                  // 158
  return pipes;                                                                                                        // 159
                                                                                                                       //
  function buildGroup() {                                                                                              // 161
    var groupDef = {                                                                                                   // 162
      _id: {                                                                                                           // 162
        time: "$value.startTime"                                                                                       // 162
      }                                                                                                                // 162
    };                                                                                                                 // 162
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 163
      groupDef._id.host = "$value.host";                                                                               // 164
    }                                                                                                                  // 165
                                                                                                                       //
    groupDef.resTime = {                                                                                               // 167
      "$sum": KadiraDataHelpers.safeMultiply("$value.resTime", "$value.subs")                                          // 168
    };                                                                                                                 // 168
    groupDef.count = {                                                                                                 // 169
      "$sum": "$value.subs"                                                                                            // 169
    };                                                                                                                 // 169
    return groupDef;                                                                                                   // 170
  }                                                                                                                    // 171
}, []);                                                                                                                // 172
KadiraData.defineMetrics("timeseries.polledDocuments", "pubMetrics", function (args) {                                 // 176
  var groupByHost = args.groupByHost;                                                                                  // 178
  var query = args.query;                                                                                              // 179
  var selectedPublication = args.selection;                                                                            // 181
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 182
    query["value.pub"] = selectedPublication;                                                                          // 183
  }                                                                                                                    // 184
                                                                                                                       //
  var pipes = [];                                                                                                      // 186
  pipes.push({                                                                                                         // 187
    $match: query                                                                                                      // 187
  });                                                                                                                  // 187
  pipes.push({                                                                                                         // 188
    $group: buildGroup()                                                                                               // 188
  });                                                                                                                  // 188
  pipes.push({                                                                                                         // 189
    $sort: {                                                                                                           // 189
      _id: 1                                                                                                           // 189
    }                                                                                                                  // 189
  });                                                                                                                  // 189
  return pipes;                                                                                                        // 190
                                                                                                                       //
  function buildGroup() {                                                                                              // 192
    var groupDef = {                                                                                                   // 193
      _id: {                                                                                                           // 193
        time: "$value.startTime"                                                                                       // 193
      }                                                                                                                // 193
    };                                                                                                                 // 193
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 194
      groupDef._id.host = "$value.host";                                                                               // 195
    }                                                                                                                  // 196
                                                                                                                       //
    groupDef.polledDocuments = {                                                                                       // 198
      "$sum": "$value.polledDocuments"                                                                                 // 198
    };                                                                                                                 // 198
    return groupDef;                                                                                                   // 199
  }                                                                                                                    // 200
}, [KadiraDataFilters.roundTo(["polledDocuments"], 2), KadiraDataFilters.addZeros(["polledDocuments"])]);              // 201
KadiraData.defineMetrics("timeseries.oplogNotifications", "pubMetrics", function (args) {                              // 206
  var query = args.query;                                                                                              // 209
  var selectedPublication = args.selection;                                                                            // 211
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 212
    query["value.pub"] = selectedPublication;                                                                          // 213
  }                                                                                                                    // 214
                                                                                                                       //
  var pipes = [];                                                                                                      // 215
  pipes.push({                                                                                                         // 216
    $match: query                                                                                                      // 216
  });                                                                                                                  // 216
  pipes.push({                                                                                                         // 217
    $group: buildGroup()                                                                                               // 217
  });                                                                                                                  // 217
  pipes.push({                                                                                                         // 218
    $sort: {                                                                                                           // 218
      _id: 1                                                                                                           // 218
    }                                                                                                                  // 218
  });                                                                                                                  // 218
                                                                                                                       //
  function buildGroup() {                                                                                              // 220
    var groupDef = {                                                                                                   // 221
      _id: {                                                                                                           // 221
        time: "$value.startTime"                                                                                       // 221
      }                                                                                                                // 221
    };                                                                                                                 // 221
    groupDef.oplogInsertedDocuments = {                                                                                // 223
      "$sum": "$value.oplogInsertedDocuments"                                                                          // 223
    };                                                                                                                 // 223
    groupDef.oplogUpdatedDocuments = {                                                                                 // 224
      "$sum": "$value.oplogUpdatedDocuments"                                                                           // 224
    };                                                                                                                 // 224
    groupDef.oplogDeletedDocuments = {                                                                                 // 225
      "$sum": "$value.oplogDeletedDocuments"                                                                           // 225
    };                                                                                                                 // 225
    return groupDef;                                                                                                   // 226
  }                                                                                                                    // 227
                                                                                                                       //
  return pipes;                                                                                                        // 229
}, [KadiraDataFilters.roundTo(["oplogInsertedDocuments", "oplogUpdatedDocuments", "oplogDeletedDocuments"], 2), KadiraDataFilters.addZeros(["oplogInsertedDocuments", "oplogUpdatedDocuments", "oplogDeletedDocuments"])]);
KadiraData.defineMetrics("timeseries.liveUpdates", "pubMetrics", function (args) {                                     // 240
  var query = args.query;                                                                                              // 243
  var selectedPublication = args.selection;                                                                            // 245
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 246
    query["value.pub"] = selectedPublication;                                                                          // 247
  }                                                                                                                    // 248
                                                                                                                       //
  var pipes = [];                                                                                                      // 249
  pipes.push({                                                                                                         // 250
    $match: query                                                                                                      // 250
  });                                                                                                                  // 250
  pipes.push({                                                                                                         // 251
    $group: buildGroup()                                                                                               // 251
  });                                                                                                                  // 251
  pipes.push({                                                                                                         // 252
    $sort: {                                                                                                           // 252
      _id: 1                                                                                                           // 252
    }                                                                                                                  // 252
  });                                                                                                                  // 252
                                                                                                                       //
  function buildGroup() {                                                                                              // 254
    var groupDef = {                                                                                                   // 255
      _id: {                                                                                                           // 255
        time: "$value.startTime"                                                                                       // 255
      }                                                                                                                // 255
    };                                                                                                                 // 255
    groupDef.initiallyAddedDocuments = {                                                                               // 257
      "$sum": "$value.initiallyAddedDocuments"                                                                         // 258
    };                                                                                                                 // 257
    groupDef.liveAddedDocuments = {                                                                                    // 260
      "$sum": "$value.liveAddedDocuments"                                                                              // 260
    };                                                                                                                 // 260
    groupDef.liveChangedDocuments = {                                                                                  // 261
      "$sum": "$value.liveChangedDocuments"                                                                            // 261
    };                                                                                                                 // 261
    groupDef.liveRemovedDocuments = {                                                                                  // 262
      "$sum": "$value.liveRemovedDocuments"                                                                            // 262
    };                                                                                                                 // 262
    return groupDef;                                                                                                   // 263
  }                                                                                                                    // 264
                                                                                                                       //
  return pipes;                                                                                                        // 266
}, [KadiraDataFilters.roundTo(["initiallyAddedDocuments", "liveAddedDocuments", "liveChangedDocuments", "liveRemovedDocuments"], 2), KadiraDataFilters.addZeros(["initiallyAddedDocuments", "liveAddedDocuments", "liveChangedDocuments", "liveRemovedDocuments"])]);
KadiraData.defineMetrics("timeseries.observerLifeTime", "pubMetrics", function (args) {                                // 279
  var query = args.query;                                                                                              // 282
  var selectedPublication = args.selection;                                                                            // 284
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 285
    query["value.pub"] = selectedPublication;                                                                          // 286
  }                                                                                                                    // 287
                                                                                                                       //
  var pipes = [];                                                                                                      // 288
  pipes.push({                                                                                                         // 289
    $match: query                                                                                                      // 289
  });                                                                                                                  // 289
  pipes.push({                                                                                                         // 290
    $group: buildGroup()                                                                                               // 290
  });                                                                                                                  // 290
  pipes.push({                                                                                                         // 291
    $project: {                                                                                                        // 291
      _id: "$_id",                                                                                                     // 292
      observerLifetime: KadiraDataHelpers.divideWithZero("$observerLifetime", "$count", true)                          // 293
    }                                                                                                                  // 291
  });                                                                                                                  // 291
  pipes.push({                                                                                                         // 296
    $sort: {                                                                                                           // 296
      _id: 1                                                                                                           // 296
    }                                                                                                                  // 296
  });                                                                                                                  // 296
                                                                                                                       //
  function buildGroup() {                                                                                              // 298
    var groupId = {                                                                                                    // 299
      time: "$value.startTime"                                                                                         // 300
    };                                                                                                                 // 299
    var groupDef = {                                                                                                   // 302
      _id: groupId                                                                                                     // 302
    };                                                                                                                 // 302
    groupDef.observerLifetime = {                                                                                      // 304
      "$sum": "$value.observerLifetime"                                                                                // 304
    };                                                                                                                 // 304
    var condition = [{                                                                                                 // 305
      "$eq": ["$value.observerLifetime", 0]                                                                            // 305
    }, 0, 1];                                                                                                          // 305
    groupDef.count = {                                                                                                 // 306
      "$sum": {                                                                                                        // 306
        "$cond": condition                                                                                             // 306
      }                                                                                                                // 306
    };                                                                                                                 // 306
    return groupDef;                                                                                                   // 307
  }                                                                                                                    // 308
                                                                                                                       //
  return pipes;                                                                                                        // 310
}, [KadiraDataFilters.roundTo(["observerLifetime"], 2), KadiraDataFilters.addZeros(["observerLifetime"])]);            // 312
KadiraData.defineMetrics("timeseries.activeSubs", "pubMetrics", function (args) {                                      // 317
  var query = args.query;                                                                                              // 320
  var selectedPublication = args.selection;                                                                            // 322
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 323
    query["value.pub"] = selectedPublication;                                                                          // 324
  }                                                                                                                    // 325
                                                                                                                       //
  var pipes = [];                                                                                                      // 326
  pipes.push({                                                                                                         // 327
    $match: query                                                                                                      // 327
  });                                                                                                                  // 327
  pipes.push({                                                                                                         // 328
    $group: buildGroup()                                                                                               // 328
  });                                                                                                                  // 328
  pipes.push({                                                                                                         // 329
    $group: buildPostGroup()                                                                                           // 329
  });                                                                                                                  // 329
  pipes.push({                                                                                                         // 330
    $project: {                                                                                                        // 330
      _id: "$_id",                                                                                                     // 331
      activeSubs: "$activeSubs"                                                                                        // 332
    }                                                                                                                  // 330
  });                                                                                                                  // 330
  pipes.push({                                                                                                         // 334
    $sort: {                                                                                                           // 334
      _id: 1                                                                                                           // 334
    }                                                                                                                  // 334
  });                                                                                                                  // 334
                                                                                                                       //
  function buildGroup() {                                                                                              // 336
    var groupId = {                                                                                                    // 337
      time: "$value.startTime",                                                                                        // 338
      host: "$value.host",                                                                                             // 339
      pub: "$value.pub"                                                                                                // 340
    };                                                                                                                 // 337
    var groupDef = {                                                                                                   // 342
      _id: groupId                                                                                                     // 342
    };                                                                                                                 // 342
    groupDef.activeSubs = {                                                                                            // 344
      "$avg": "$value.activeSubs"                                                                                      // 344
    };                                                                                                                 // 344
    return groupDef;                                                                                                   // 345
  }                                                                                                                    // 346
                                                                                                                       //
  function buildPostGroup() {                                                                                          // 348
    var groupDef = {                                                                                                   // 349
      _id: {                                                                                                           // 349
        time: "$_id.time"                                                                                              // 349
      }                                                                                                                // 349
    };                                                                                                                 // 349
    groupDef.activeSubs = {                                                                                            // 351
      "$sum": "$activeSubs"                                                                                            // 351
    };                                                                                                                 // 351
    return groupDef;                                                                                                   // 352
  }                                                                                                                    // 353
                                                                                                                       //
  return pipes;                                                                                                        // 355
}, [KadiraDataFilters.roundTo(["activeSubs"], 2), KadiraDataFilters.addZeros(["activeSubs"])]);                        // 357
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dashboard.methods.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/dashboard.methods.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("breakdown.methods", "methodsMetrics", function (args) {                                      // 1
  var query = args.query;                                                                                              // 2
  var pipes = [];                                                                                                      // 3
  var projectDef = {};                                                                                                 // 4
  var groupDef = {};                                                                                                   // 5
  var sortDef = {                                                                                                      // 6
    "sortedValue": -1                                                                                                  // 6
  };                                                                                                                   // 6
  pipes.push({                                                                                                         // 7
    $match: query                                                                                                      // 7
  });                                                                                                                  // 7
  pipes.push({                                                                                                         // 8
    $group: groupDef                                                                                                   // 8
  });                                                                                                                  // 8
  pipes.push({                                                                                                         // 9
    $project: projectDef                                                                                               // 9
  });                                                                                                                  // 9
  pipes.push({                                                                                                         // 10
    $sort: sortDef                                                                                                     // 10
  });                                                                                                                  // 10
  pipes.push({                                                                                                         // 11
    $limit: 50                                                                                                         // 11
  }); // build group                                                                                                   // 11
                                                                                                                       //
  groupDef._id = "$value.name";                                                                                        // 14
  groupDef.commonValue = {                                                                                             // 15
    "$sum": "$value.count"                                                                                             // 15
  }; // build project                                                                                                  // 15
                                                                                                                       //
  projectDef.commonValue = "$commonValue";                                                                             // 18
  projectDef.sortValueTitle = "$_id";                                                                                  // 19
  projectDef.id = "$_id";                                                                                              // 20
                                                                                                                       //
  switch (args.sortBy) {                                                                                               // 22
    case "count":                                                                                                      // 23
      groupDef.sortedValue = {                                                                                         // 24
        "$sum": "$value." + args.sortBy                                                                                // 24
      };                                                                                                               // 24
      projectDef.sortedValue = "$sortedValue";                                                                         // 25
      break;                                                                                                           // 26
                                                                                                                       //
    default:                                                                                                           // 27
      calculateResTime(args.sortBy, "count");                                                                          // 28
      break;                                                                                                           // 29
  }                                                                                                                    // 22
                                                                                                                       //
  function calculateResTime(avgValue, sampleValue) {                                                                   // 32
    groupDef.sum = {                                                                                                   // 33
      "$sum": KadiraDataHelpers.safeMultiply("$value." + avgValue, "$value." + sampleValue)                            // 34
    };                                                                                                                 // 33
    groupDef.samples = {                                                                                               // 37
      "$sum": "$value." + sampleValue                                                                                  // 37
    };                                                                                                                 // 37
    projectDef.sortedValue = KadiraDataHelpers.divideWithZero("$sum", "$samples", true);                               // 38
  }                                                                                                                    // 40
                                                                                                                       //
  return pipes;                                                                                                        // 42
}, [KadiraDataFilters.rateFilterForBreakdown(["count"]), KadiraDataFilters.roundTo(["commonValue"], 2)]);              // 43
KadiraData.defineMetrics("timeseries.responseTimeBreakdown", "methodsMetrics", function (args) {                       // 48
  var query = args.query;                                                                                              // 51
  var selectedPublication = args.selection;                                                                            // 53
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 54
    query["value.name"] = selectedPublication;                                                                         // 55
  }                                                                                                                    // 56
                                                                                                                       //
  var groupDef = {                                                                                                     // 58
    _id: {                                                                                                             // 58
      time: "$value.startTime"                                                                                         // 58
    }                                                                                                                  // 58
  };                                                                                                                   // 58
  var projectDef = {                                                                                                   // 59
    _id: "$_id"                                                                                                        // 59
  };                                                                                                                   // 59
  var pipes = [];                                                                                                      // 60
  pipes.push({                                                                                                         // 61
    $match: query                                                                                                      // 61
  });                                                                                                                  // 61
  pipes.push({                                                                                                         // 62
    $group: groupDef                                                                                                   // 62
  });                                                                                                                  // 62
  pipes.push({                                                                                                         // 63
    $project: projectDef                                                                                               // 63
  });                                                                                                                  // 63
  pipes.push({                                                                                                         // 64
    $sort: {                                                                                                           // 64
      _id: 1                                                                                                           // 64
    }                                                                                                                  // 64
  });                                                                                                                  // 64
  groupDef.count = {                                                                                                   // 66
    "$sum": "$value.count"                                                                                             // 66
  };                                                                                                                   // 66
  ["wait", "db", "http", "email", "compute", "async"].forEach(function (metric) {                                      // 67
    groupDef[metric] = {                                                                                               // 68
      "$sum": KadiraDataHelpers.safeMultiply("$value." + metric, "$value.count")                                       // 69
    };                                                                                                                 // 68
    projectDef[metric] = KadiraDataHelpers.divideWithZero("$" + metric, "$count", true);                               // 71
  });                                                                                                                  // 73
  return pipes;                                                                                                        // 75
}, [KadiraDataFilters.roundTo(["wait", "db", "http", "email", "compute", "async"], 2), KadiraDataFilters.addZeros(["wait", "db", "http", "email", "compute", "async"])]);
KadiraData.defineMetrics("timeseries.throughput", "methodsMetrics", function (args) {                                  // 86
  var query = args.query;                                                                                              // 88
  var selectedMethod = args.selection;                                                                                 // 90
                                                                                                                       //
  if (selectedMethod) {                                                                                                // 91
    query["value.name"] = selectedMethod;                                                                              // 92
  }                                                                                                                    // 93
                                                                                                                       //
  var pipes = [];                                                                                                      // 95
  pipes.push({                                                                                                         // 96
    $match: query                                                                                                      // 96
  });                                                                                                                  // 96
  pipes.push({                                                                                                         // 97
    $group: buildGroup()                                                                                               // 97
  });                                                                                                                  // 97
  pipes.push({                                                                                                         // 98
    $sort: {                                                                                                           // 98
      _id: 1                                                                                                           // 98
    }                                                                                                                  // 98
  });                                                                                                                  // 98
  return pipes;                                                                                                        // 99
                                                                                                                       //
  function buildGroup() {                                                                                              // 101
    var groupDef = {                                                                                                   // 102
      _id: {                                                                                                           // 102
        time: "$value.startTime"                                                                                       // 102
      }                                                                                                                // 102
    };                                                                                                                 // 102
    groupDef.count = {                                                                                                 // 103
      "$sum": "$value.count"                                                                                           // 103
    };                                                                                                                 // 103
    return groupDef;                                                                                                   // 104
  }                                                                                                                    // 105
}, [KadiraDataFilters.rateFilterForCharts(["count"]), KadiraDataFilters.roundTo(["count"], 2), KadiraDataFilters.addZeros(["count"])]);
KadiraData.defineMetrics("timeseries.resTimeThroughput", "methodsMetrics", function (args) {                           // 112
  var query = args.query;                                                                                              // 114
  var selectedPublication = args.selection;                                                                            // 116
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 117
    query["value.name"] = selectedPublication;                                                                         // 118
  }                                                                                                                    // 119
                                                                                                                       //
  var groupDef = {                                                                                                     // 121
    _id: {                                                                                                             // 121
      time: "$value.startTime"                                                                                         // 121
    }                                                                                                                  // 121
  };                                                                                                                   // 121
  var projectDef = {                                                                                                   // 122
    _id: "$_id"                                                                                                        // 122
  };                                                                                                                   // 122
  var pipes = [];                                                                                                      // 123
  pipes.push({                                                                                                         // 124
    $match: query                                                                                                      // 124
  });                                                                                                                  // 124
  pipes.push({                                                                                                         // 125
    $group: groupDef                                                                                                   // 125
  });                                                                                                                  // 125
  pipes.push({                                                                                                         // 126
    $project: projectDef                                                                                               // 126
  });                                                                                                                  // 126
  pipes.push({                                                                                                         // 127
    $sort: {                                                                                                           // 127
      _id: 1                                                                                                           // 127
    }                                                                                                                  // 127
  });                                                                                                                  // 127
  groupDef.count = {                                                                                                   // 129
    "$sum": "$value.count"                                                                                             // 129
  };                                                                                                                   // 129
  projectDef.count = "$count";                                                                                         // 130
  groupDef.total = {                                                                                                   // 132
    "$sum": KadiraDataHelpers.safeMultiply("$value.total", "$value.count")                                             // 133
  };                                                                                                                   // 132
  projectDef.total = KadiraDataHelpers.divideWithZero("$total", "$count", true);                                       // 135
  return pipes;                                                                                                        // 138
}, [KadiraDataFilters.rateFilterForCharts(["count"]), KadiraDataFilters.roundTo(["count", "total"], 2), KadiraDataFilters.addZeros(["count", "total"])]);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dashboard.overview.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/dashboard.overview.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("timeseries.memory", "systemMetrics", function (args) {                                       // 1
  var groupByHost = args.groupByHost;                                                                                  // 2
  var query = args.query;                                                                                              // 3
  var pipes = [];                                                                                                      // 5
  pipes.push({                                                                                                         // 6
    $match: query                                                                                                      // 6
  });                                                                                                                  // 6
  pipes.push({                                                                                                         // 7
    $group: buildGroup()                                                                                               // 7
  });                                                                                                                  // 7
  pipes.push({                                                                                                         // 8
    $sort: {                                                                                                           // 8
      _id: 1                                                                                                           // 8
    }                                                                                                                  // 8
  });                                                                                                                  // 8
  return pipes;                                                                                                        // 9
                                                                                                                       //
  function buildGroup() {                                                                                              // 11
    var groupDef = {                                                                                                   // 12
      _id: {                                                                                                           // 12
        time: "$value.startTime"                                                                                       // 12
      }                                                                                                                // 12
    };                                                                                                                 // 12
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 13
      groupDef._id.host = "$value.host";                                                                               // 14
    }                                                                                                                  // 15
                                                                                                                       //
    groupDef.memory = {                                                                                                // 17
      "$avg": "$value.memory"                                                                                          // 17
    };                                                                                                                 // 17
    return groupDef;                                                                                                   // 18
  }                                                                                                                    // 19
}, [KadiraDataFilters.roundTo(["memory"], 2), KadiraDataFilters.addZeros(["memory"])]);                                // 20
KadiraData.defineMetrics("timeseries.pcpu", "systemMetrics", function (args) {                                         // 25
  var groupByHost = args.groupByHost;                                                                                  // 26
  var query = args.query;                                                                                              // 27
  var pipes = [];                                                                                                      // 29
  pipes.push({                                                                                                         // 30
    $match: query                                                                                                      // 30
  });                                                                                                                  // 30
  pipes.push({                                                                                                         // 31
    $group: buildGroup()                                                                                               // 31
  });                                                                                                                  // 31
  pipes.push({                                                                                                         // 32
    $sort: {                                                                                                           // 32
      _id: 1                                                                                                           // 32
    }                                                                                                                  // 32
  });                                                                                                                  // 32
  return pipes;                                                                                                        // 33
                                                                                                                       //
  function buildGroup() {                                                                                              // 35
    var groupDef = {                                                                                                   // 36
      _id: {                                                                                                           // 36
        time: "$value.startTime"                                                                                       // 36
      }                                                                                                                // 36
    };                                                                                                                 // 36
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 37
      groupDef._id.host = "$value.host";                                                                               // 38
    }                                                                                                                  // 39
                                                                                                                       //
    groupDef.pcpu = {                                                                                                  // 41
      "$avg": "$value.pcpu"                                                                                            // 41
    };                                                                                                                 // 41
    return groupDef;                                                                                                   // 42
  }                                                                                                                    // 43
}, [KadiraDataFilters.toPct(2), KadiraDataFilters.addZeros(["pcpu"])]);                                                // 44
KadiraData.defineMetrics("timeseries.pubsubResTime", "pubMetrics", function (args) {                                   // 49
  var groupByHost = args.groupByHost;                                                                                  // 51
  var query = args.query;                                                                                              // 52
  var selectedPublication = args.selection;                                                                            // 54
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 55
    query["value.pub"] = selectedPublication;                                                                          // 56
  }                                                                                                                    // 57
                                                                                                                       //
  var pipes = [];                                                                                                      // 59
  pipes.push({                                                                                                         // 60
    $match: query                                                                                                      // 60
  });                                                                                                                  // 60
  pipes.push({                                                                                                         // 61
    $group: buildGroup()                                                                                               // 61
  });                                                                                                                  // 61
  pipes.push({                                                                                                         // 62
    $project: {                                                                                                        // 62
      _id: "$_id",                                                                                                     // 63
      resTime: KadiraDataHelpers.divideWithZero("$resTime", "$count", true)                                            // 64
    }                                                                                                                  // 62
  });                                                                                                                  // 62
  pipes.push({                                                                                                         // 67
    $sort: {                                                                                                           // 67
      _id: 1                                                                                                           // 67
    }                                                                                                                  // 67
  });                                                                                                                  // 67
  return pipes;                                                                                                        // 68
                                                                                                                       //
  function buildGroup() {                                                                                              // 70
    var groupDef = {                                                                                                   // 71
      _id: {                                                                                                           // 71
        time: "$value.startTime"                                                                                       // 71
      }                                                                                                                // 71
    };                                                                                                                 // 71
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 72
      groupDef._id.host = "$value.host";                                                                               // 73
    }                                                                                                                  // 74
                                                                                                                       //
    groupDef.resTime = {                                                                                               // 76
      "$sum": KadiraDataHelpers.safeMultiply("$value.resTime", "$value.subs")                                          // 77
    };                                                                                                                 // 76
    groupDef.count = {                                                                                                 // 79
      "$sum": "$value.subs"                                                                                            // 79
    };                                                                                                                 // 79
    return groupDef;                                                                                                   // 80
  }                                                                                                                    // 81
}, [KadiraDataFilters.roundTo(["resTime"], 2), KadiraDataFilters.addZeros(["resTime"])]);                              // 82
KadiraData.defineMetrics("timeseries.methodResTime", "methodsMetrics", function (args) {                               // 87
  var groupByHost = args.groupByHost;                                                                                  // 89
  var query = args.query;                                                                                              // 90
  var pipes = [];                                                                                                      // 92
  pipes.push({                                                                                                         // 93
    $match: query                                                                                                      // 93
  });                                                                                                                  // 93
  pipes.push({                                                                                                         // 94
    $group: buildGroup()                                                                                               // 94
  });                                                                                                                  // 94
  pipes.push({                                                                                                         // 95
    $project: {                                                                                                        // 95
      _id: "$_id",                                                                                                     // 96
      resTime: KadiraDataHelpers.divideWithZero("$resTime", "$count", true)                                            // 97
    }                                                                                                                  // 95
  });                                                                                                                  // 95
  pipes.push({                                                                                                         // 99
    $sort: {                                                                                                           // 99
      _id: 1                                                                                                           // 99
    }                                                                                                                  // 99
  });                                                                                                                  // 99
  return pipes;                                                                                                        // 100
                                                                                                                       //
  function buildGroup() {                                                                                              // 102
    var groupDef = {                                                                                                   // 103
      _id: {                                                                                                           // 103
        time: "$value.startTime"                                                                                       // 103
      }                                                                                                                // 103
    };                                                                                                                 // 103
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 104
      groupDef._id.host = "$value.host";                                                                               // 105
    }                                                                                                                  // 106
                                                                                                                       //
    groupDef.resTime = {                                                                                               // 108
      "$sum": KadiraDataHelpers.safeMultiply("$value.total", "$value.count")                                           // 109
    };                                                                                                                 // 108
    groupDef.count = {                                                                                                 // 111
      "$sum": "$value.count"                                                                                           // 111
    };                                                                                                                 // 111
    return groupDef;                                                                                                   // 112
  }                                                                                                                    // 113
}, [KadiraDataFilters.roundTo(["resTime"], 2), KadiraDataFilters.addZeros(["resTime"])]);                              // 114
KadiraData.defineMetrics("timeseries.sessions", "systemMetrics", function (args) {                                     // 119
  var groupByHost = args.groupByHost;                                                                                  // 121
  var query = args.query;                                                                                              // 122
  var pipes = [];                                                                                                      // 124
  pipes.push({                                                                                                         // 125
    $match: query                                                                                                      // 125
  });                                                                                                                  // 125
  pipes.push({                                                                                                         // 126
    $group: buildGroup()                                                                                               // 126
  });                                                                                                                  // 126
  pipes.push({                                                                                                         // 127
    $sort: {                                                                                                           // 127
      _id: 1                                                                                                           // 127
    }                                                                                                                  // 127
  });                                                                                                                  // 127
  return pipes;                                                                                                        // 128
                                                                                                                       //
  function buildGroup() {                                                                                              // 130
    var groupDef = {                                                                                                   // 131
      _id: {                                                                                                           // 131
        time: "$value.startTime"                                                                                       // 131
      }                                                                                                                // 131
    };                                                                                                                 // 131
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 132
      groupDef._id.host = "$value.host";                                                                               // 133
    }                                                                                                                  // 134
                                                                                                                       //
    groupDef.sessions = {                                                                                              // 136
      "$sum": "$value.sessions"                                                                                        // 136
    };                                                                                                                 // 136
    return groupDef;                                                                                                   // 137
  }                                                                                                                    // 138
}, [KadiraDataFilters.roundTo(["sessions"], 0), KadiraDataFilters.addZeros(["sessions"])]);                            // 139
KadiraData.defineMetrics("timeseries.createdObservers", "pubMetrics", function (args) {                                // 144
  var groupByHost = args.groupByHost;                                                                                  // 146
  var query = args.query;                                                                                              // 147
  var pipes = [];                                                                                                      // 149
  pipes.push({                                                                                                         // 150
    $match: query                                                                                                      // 150
  });                                                                                                                  // 150
  pipes.push({                                                                                                         // 151
    $group: buildGroup()                                                                                               // 151
  });                                                                                                                  // 151
  pipes.push({                                                                                                         // 152
    $sort: {                                                                                                           // 152
      _id: 1                                                                                                           // 152
    }                                                                                                                  // 152
  });                                                                                                                  // 152
  return pipes;                                                                                                        // 153
                                                                                                                       //
  function buildGroup() {                                                                                              // 155
    var groupDef = {                                                                                                   // 156
      _id: {                                                                                                           // 156
        time: "$value.startTime"                                                                                       // 156
      }                                                                                                                // 156
    };                                                                                                                 // 156
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 157
      groupDef._id.host = "$value.host";                                                                               // 158
    }                                                                                                                  // 159
                                                                                                                       //
    groupDef.createdObservers = {                                                                                      // 161
      "$sum": "$value.createdObservers"                                                                                // 161
    };                                                                                                                 // 161
    return groupDef;                                                                                                   // 162
  }                                                                                                                    // 163
}, [KadiraDataFilters.roundTo(["createdObservers"], 0), KadiraDataFilters.addZeros(["createdObservers"])]);            // 164
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dashboard.pubsub.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/dashboard.pubsub.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("breakdown.pubsub", "pubMetrics", function (args) {                                           // 1
  var query = args.query;                                                                                              // 2
  var pipes = [];                                                                                                      // 3
  var projectDef = {};                                                                                                 // 4
  var groupDef = {};                                                                                                   // 5
  var sortDef = {                                                                                                      // 6
    "sortedValue": -1                                                                                                  // 6
  };                                                                                                                   // 6
  pipes.push({                                                                                                         // 7
    $match: query                                                                                                      // 7
  });                                                                                                                  // 7
  pipes.push({                                                                                                         // 8
    $group: groupDef                                                                                                   // 8
  });                                                                                                                  // 8
  pipes.push({                                                                                                         // 9
    $project: projectDef                                                                                               // 9
  });                                                                                                                  // 9
  pipes.push({                                                                                                         // 10
    $sort: sortDef                                                                                                     // 10
  });                                                                                                                  // 10
  pipes.push({                                                                                                         // 11
    $limit: 50                                                                                                         // 11
  }); // build group                                                                                                   // 11
                                                                                                                       //
  groupDef._id = "$value.pub";                                                                                         // 14
  groupDef.commonValue = {                                                                                             // 15
    "$sum": "$value.subs"                                                                                              // 15
  }; // build project                                                                                                  // 15
                                                                                                                       //
  projectDef.commonValue = "$commonValue";                                                                             // 18
  projectDef.sortValueTitle = "$_id";                                                                                  // 19
  projectDef.id = "$_id";                                                                                              // 20
                                                                                                                       //
  switch (args.sortBy) {                                                                                               // 22
    case "unsubs":                                                                                                     // 23
    case "subs":                                                                                                       // 24
    case "createdObservers":                                                                                           // 25
    case "deletedObservers":                                                                                           // 26
    case "totalObserverHandlers":                                                                                      // 27
    case "cachedObservers":                                                                                            // 28
      groupDef.sortedValue = {                                                                                         // 29
        "$sum": "$value." + args.sortBy                                                                                // 29
      };                                                                                                               // 29
      projectDef.sortedValue = "$sortedValue";                                                                         // 30
      break;                                                                                                           // 31
                                                                                                                       //
    case "resTime":                                                                                                    // 32
      calculateResTime(args.sortBy, "subs");                                                                           // 33
      break;                                                                                                           // 34
                                                                                                                       //
    case "lifeTime":                                                                                                   // 35
      sortDef.sortedValue = 1;                                                                                         // 36
      calculateResTime(args.sortBy, "unsubs");                                                                         // 37
      break;                                                                                                           // 38
                                                                                                                       //
    case "activeSubs":                                                                                                 // 39
      // we override how we group here. We need grouped by both pub and host                                           // 40
      groupDef._id = {                                                                                                 // 41
        pub: "$value.pub",                                                                                             // 41
        host: "$value.host"                                                                                            // 41
      };                                                                                                               // 41
      groupDef.sortedValue = {                                                                                         // 42
        "$avg": "$value." + args.sortBy                                                                                // 42
      }; // then we need to post aggregate it.                                                                         // 42
                                                                                                                       //
      var postGroupDef = {                                                                                             // 45
        _id: "$_id.pub",                                                                                               // 46
        sortedValue: {                                                                                                 // 47
          $sum: "$sortedValue"                                                                                         // 47
        },                                                                                                             // 47
        commonValue: {                                                                                                 // 48
          $sum: "$commonValue"                                                                                         // 48
        }                                                                                                              // 48
      };                                                                                                               // 45
      pipes.splice(2, 0, {                                                                                             // 50
        $group: postGroupDef                                                                                           // 50
      });                                                                                                              // 50
      projectDef.sortedValue = "$sortedValue";                                                                         // 51
      break;                                                                                                           // 52
                                                                                                                       //
    case "cacheMiss":                                                                                                  // 53
      calculateObserverRatio();                                                                                        // 54
      sortDef.sortedValue = 1;                                                                                         // 55
      break;                                                                                                           // 56
                                                                                                                       //
    case "cacheHits":                                                                                                  // 57
      calculateObserverRatio();                                                                                        // 58
      sortDef.sortedValue = -1;                                                                                        // 59
      break;                                                                                                           // 60
  }                                                                                                                    // 22
                                                                                                                       //
  function calculateObserverRatio() {                                                                                  // 63
    groupDef.total = {                                                                                                 // 64
      "$sum": "$value.totalObserverHandlers"                                                                           // 64
    };                                                                                                                 // 64
    groupDef.cached = {                                                                                                // 65
      "$sum": "$value.cachedObservers"                                                                                 // 65
    };                                                                                                                 // 65
    projectDef.sortedValue = KadiraDataHelpers.safeMultiply(KadiraDataHelpers.divideWithZero("$cached", "$total"), 100);
  }                                                                                                                    // 70
                                                                                                                       //
  function calculateResTime(avgValue, sampleValue) {                                                                   // 72
    groupDef.sum = {                                                                                                   // 73
      "$sum": KadiraDataHelpers.safeMultiply("$value." + avgValue, "$value." + sampleValue)                            // 74
    };                                                                                                                 // 73
    groupDef.samples = {                                                                                               // 77
      "$sum": "$value." + sampleValue                                                                                  // 77
    };                                                                                                                 // 77
    projectDef.sortedValue = KadiraDataHelpers.divideWithZero("$sum", "$samples", true);                               // 78
  }                                                                                                                    // 80
                                                                                                                       //
  return pipes;                                                                                                        // 82
}, [KadiraDataFilters.rateFilterForBreakdown(["subs", "unsubs"]), KadiraDataFilters.roundTo(["commonValue"], 2)]);     // 83
KadiraData.defineMetrics("timeseries.subRate", "pubMetrics", function (args) {                                         // 88
  var groupByHost = args.groupByHost;                                                                                  // 89
  var query = args.query;                                                                                              // 90
  var selectedPublication = args.selection;                                                                            // 92
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 93
    query["value.pub"] = selectedPublication;                                                                          // 94
  }                                                                                                                    // 95
                                                                                                                       //
  var pipes = [];                                                                                                      // 97
  pipes.push({                                                                                                         // 98
    $match: query                                                                                                      // 98
  });                                                                                                                  // 98
  pipes.push({                                                                                                         // 99
    $group: buildGroup()                                                                                               // 99
  });                                                                                                                  // 99
  pipes.push({                                                                                                         // 100
    $sort: {                                                                                                           // 100
      _id: 1                                                                                                           // 100
    }                                                                                                                  // 100
  });                                                                                                                  // 100
  return pipes;                                                                                                        // 101
                                                                                                                       //
  function buildGroup() {                                                                                              // 103
    var groupDef = {                                                                                                   // 104
      _id: {                                                                                                           // 104
        time: "$value.startTime"                                                                                       // 104
      }                                                                                                                // 104
    };                                                                                                                 // 104
                                                                                                                       //
    if (groupByHost) {                                                                                                 // 105
      groupDef._id.host = "$value.host";                                                                               // 106
    }                                                                                                                  // 107
                                                                                                                       //
    groupDef.subs = {                                                                                                  // 109
      "$sum": "$value.subs"                                                                                            // 109
    };                                                                                                                 // 109
    return groupDef;                                                                                                   // 110
  }                                                                                                                    // 111
}, [KadiraDataFilters.rateFilterForCharts(["subs"]), KadiraDataFilters.roundTo(["subs"], 2), KadiraDataFilters.addZeros(["subs"])]);
KadiraData.defineMetrics("timeseries.subRateResTime", "pubMetrics", function (args) {                                  // 118
  var query = args.query;                                                                                              // 121
  var selectedPublication = args.selection;                                                                            // 123
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 124
    query["value.pub"] = selectedPublication;                                                                          // 125
  }                                                                                                                    // 126
                                                                                                                       //
  var pipes = [];                                                                                                      // 128
  pipes.push({                                                                                                         // 129
    $match: query                                                                                                      // 129
  });                                                                                                                  // 129
  pipes.push({                                                                                                         // 130
    $group: buildGroup()                                                                                               // 130
  });                                                                                                                  // 130
  pipes.push({                                                                                                         // 131
    $project: {                                                                                                        // 131
      _id: "$_id",                                                                                                     // 132
      resTime: KadiraDataHelpers.divideWithZero("$resTime", "$count", true),                                           // 133
      subs: "$count"                                                                                                   // 134
    }                                                                                                                  // 131
  });                                                                                                                  // 131
  pipes.push({                                                                                                         // 137
    $sort: {                                                                                                           // 137
      _id: 1                                                                                                           // 137
    }                                                                                                                  // 137
  });                                                                                                                  // 137
  return pipes;                                                                                                        // 138
                                                                                                                       //
  function buildGroup() {                                                                                              // 140
    var groupDef = {                                                                                                   // 141
      _id: {                                                                                                           // 141
        time: "$value.startTime"                                                                                       // 141
      }                                                                                                                // 141
    };                                                                                                                 // 141
    groupDef.resTime = {                                                                                               // 143
      "$sum": KadiraDataHelpers.safeMultiply("$value.resTime", "$value.subs")                                          // 144
    };                                                                                                                 // 143
    groupDef.count = {                                                                                                 // 146
      "$sum": "$value.subs"                                                                                            // 146
    };                                                                                                                 // 146
    return groupDef;                                                                                                   // 147
  }                                                                                                                    // 148
}, [KadiraDataFilters.rateFilterForCharts(["subs"]), KadiraDataFilters.roundTo(["resTime", "subs"], 2), KadiraDataFilters.addZeros(["resTime", "subs"])]);
KadiraData.defineMetrics("timeseries.activeSubsLifeTime", "pubMetrics", function (args) {                              // 155
  var query = args.query;                                                                                              // 158
  var selectedPublication = args.selection;                                                                            // 160
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 161
    query["value.pub"] = selectedPublication;                                                                          // 162
  }                                                                                                                    // 163
                                                                                                                       //
  var pipes = [];                                                                                                      // 164
  pipes.push({                                                                                                         // 165
    $match: query                                                                                                      // 165
  });                                                                                                                  // 165
  pipes.push({                                                                                                         // 166
    $group: buildGroup()                                                                                               // 166
  });                                                                                                                  // 166
  pipes.push({                                                                                                         // 167
    $group: buildPostGroup()                                                                                           // 167
  });                                                                                                                  // 167
  pipes.push({                                                                                                         // 168
    $project: {                                                                                                        // 168
      _id: "$_id",                                                                                                     // 169
      activeSubs: "$activeSubs",                                                                                       // 170
      lifeTime: KadiraDataHelpers.divideWithZero("$lifeTime", "$count", true)                                          // 171
    }                                                                                                                  // 168
  });                                                                                                                  // 168
  pipes.push({                                                                                                         // 173
    $sort: {                                                                                                           // 173
      _id: 1                                                                                                           // 173
    }                                                                                                                  // 173
  });                                                                                                                  // 173
                                                                                                                       //
  function buildGroup() {                                                                                              // 175
    var groupId = {                                                                                                    // 176
      time: "$value.startTime",                                                                                        // 177
      host: "$value.host",                                                                                             // 178
      pub: "$value.pub"                                                                                                // 179
    };                                                                                                                 // 176
    var groupDef = {                                                                                                   // 181
      _id: groupId                                                                                                     // 181
    };                                                                                                                 // 181
    groupDef.activeSubs = {                                                                                            // 183
      "$avg": "$value.activeSubs"                                                                                      // 183
    };                                                                                                                 // 183
    groupDef.lifeTime = {                                                                                              // 184
      "$sum": "$value.lifeTime"                                                                                        // 184
    };                                                                                                                 // 184
    var condition = [{                                                                                                 // 185
      "$eq": ["$value.lifeTime", 0]                                                                                    // 185
    }, 0, 1];                                                                                                          // 185
    groupDef.count = {                                                                                                 // 186
      "$sum": {                                                                                                        // 186
        "$cond": condition                                                                                             // 186
      }                                                                                                                // 186
    };                                                                                                                 // 186
    return groupDef;                                                                                                   // 187
  }                                                                                                                    // 188
                                                                                                                       //
  function buildPostGroup() {                                                                                          // 190
    var groupDef = {                                                                                                   // 191
      _id: {                                                                                                           // 191
        time: "$_id.time"                                                                                              // 191
      }                                                                                                                // 191
    };                                                                                                                 // 191
    groupDef.activeSubs = {                                                                                            // 193
      "$sum": "$activeSubs"                                                                                            // 193
    };                                                                                                                 // 193
    groupDef.count = {                                                                                                 // 194
      "$sum": "$count"                                                                                                 // 194
    };                                                                                                                 // 194
    groupDef.lifeTime = {                                                                                              // 195
      "$sum": "$lifeTime"                                                                                              // 195
    };                                                                                                                 // 195
    return groupDef;                                                                                                   // 196
  }                                                                                                                    // 197
                                                                                                                       //
  return pipes;                                                                                                        // 199
}, [KadiraDataFilters.roundTo(["activeSubs", "lifeTime"], 2), KadiraDataFilters.addZeros(["activeSubs", "lifeTime"])]);
KadiraData.defineMetrics("timeseries.createdDeletedObservers", "pubMetrics", function (args) {                         // 206
  var query = args.query;                                                                                              // 209
  var selectedPublication = args.selection;                                                                            // 211
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 212
    query["value.pub"] = selectedPublication;                                                                          // 213
  }                                                                                                                    // 214
                                                                                                                       //
  var pipes = [];                                                                                                      // 215
  pipes.push({                                                                                                         // 216
    $match: query                                                                                                      // 216
  });                                                                                                                  // 216
  pipes.push({                                                                                                         // 217
    $group: buildGroup()                                                                                               // 217
  });                                                                                                                  // 217
  pipes.push({                                                                                                         // 218
    $sort: {                                                                                                           // 218
      _id: 1                                                                                                           // 218
    }                                                                                                                  // 218
  });                                                                                                                  // 218
                                                                                                                       //
  function buildGroup() {                                                                                              // 220
    var groupDef = {                                                                                                   // 221
      _id: {                                                                                                           // 221
        time: "$value.startTime"                                                                                       // 221
      }                                                                                                                // 221
    };                                                                                                                 // 221
    groupDef.createdObservers = {                                                                                      // 223
      "$sum": "$value.createdObservers"                                                                                // 223
    };                                                                                                                 // 223
    groupDef.deletedObservers = {                                                                                      // 224
      "$sum": "$value.deletedObservers"                                                                                // 224
    };                                                                                                                 // 224
    return groupDef;                                                                                                   // 225
  }                                                                                                                    // 226
                                                                                                                       //
  return pipes;                                                                                                        // 228
}, [KadiraDataFilters.roundTo(["createdObservers", "createdObservers"], 2), KadiraDataFilters.addZeros(["createdObservers", "deletedObservers"])]);
KadiraData.defineMetrics("timeseries.totalReusedObservers", "pubMetrics", function (args) {                            // 236
  var query = args.query;                                                                                              // 239
  var selectedPublication = args.selection;                                                                            // 241
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 242
    query["value.pub"] = selectedPublication;                                                                          // 243
  }                                                                                                                    // 244
                                                                                                                       //
  var pipes = [];                                                                                                      // 245
  pipes.push({                                                                                                         // 246
    $match: query                                                                                                      // 246
  });                                                                                                                  // 246
  pipes.push({                                                                                                         // 247
    $group: buildGroup()                                                                                               // 247
  });                                                                                                                  // 247
  pipes.push({                                                                                                         // 248
    $sort: {                                                                                                           // 248
      _id: 1                                                                                                           // 248
    }                                                                                                                  // 248
  });                                                                                                                  // 248
                                                                                                                       //
  function buildGroup() {                                                                                              // 250
    var groupDef = {                                                                                                   // 251
      _id: {                                                                                                           // 251
        time: "$value.startTime"                                                                                       // 251
      }                                                                                                                // 251
    };                                                                                                                 // 251
    groupDef.totalObserverHandlers = {                                                                                 // 253
      "$sum": "$value.totalObserverHandlers"                                                                           // 253
    };                                                                                                                 // 253
    groupDef.cachedObservers = {                                                                                       // 254
      "$sum": "$value.cachedObservers"                                                                                 // 254
    };                                                                                                                 // 254
    return groupDef;                                                                                                   // 255
  }                                                                                                                    // 256
                                                                                                                       //
  return pipes;                                                                                                        // 258
}, [KadiraDataFilters.roundTo(["totalObserverHandlers", "cachedObservers"], 2), KadiraDataFilters.addZeros(["totalObserverHandlers", "cachedObservers"])]);
KadiraData.defineMetrics("timeseries.subUnsubRates", "pubMetrics", function (args) {                                   // 265
  var query = args.query;                                                                                              // 268
  var selectedPublication = args.selection;                                                                            // 270
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 271
    query["value.pub"] = selectedPublication;                                                                          // 272
  }                                                                                                                    // 273
                                                                                                                       //
  var pipes = [];                                                                                                      // 274
  pipes.push({                                                                                                         // 275
    $match: query                                                                                                      // 275
  });                                                                                                                  // 275
  pipes.push({                                                                                                         // 276
    $group: buildGroup()                                                                                               // 276
  });                                                                                                                  // 276
  pipes.push({                                                                                                         // 277
    $sort: {                                                                                                           // 277
      _id: 1                                                                                                           // 277
    }                                                                                                                  // 277
  });                                                                                                                  // 277
                                                                                                                       //
  function buildGroup() {                                                                                              // 279
    var groupDef = {                                                                                                   // 280
      _id: {                                                                                                           // 280
        time: "$value.startTime"                                                                                       // 280
      }                                                                                                                // 280
    };                                                                                                                 // 280
    groupDef.subs = {                                                                                                  // 282
      "$sum": "$value.subs"                                                                                            // 282
    };                                                                                                                 // 282
    groupDef.unsubs = {                                                                                                // 283
      "$sum": "$value.unsubs"                                                                                          // 283
    };                                                                                                                 // 283
    return groupDef;                                                                                                   // 284
  }                                                                                                                    // 285
                                                                                                                       //
  return pipes;                                                                                                        // 287
}, [KadiraDataFilters.rateFilterForCharts(["subs", "unsubs"]), KadiraDataFilters.roundTo(["subs", "unsubs"], 2), KadiraDataFilters.addZeros(["subs", "unsubs"])]);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"errors.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/errors.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("breakdown.errors", "errorMetrics", function (args) {                                         // 1
  var query = args.query;                                                                                              // 2
  var pipes = [];                                                                                                      // 3
  var projectDef = {};                                                                                                 // 4
  var groupDef = {};                                                                                                   // 5
  var sortDef = {};                                                                                                    // 6
  groupDef._id = {                                                                                                     // 8
    name: "$value.name",                                                                                               // 8
    type: "$value.type"                                                                                                // 8
  };                                                                                                                   // 8
  projectDef.type = "$_id.type";                                                                                       // 9
  groupDef.count = {                                                                                                   // 11
    "$sum": "$value.count"                                                                                             // 11
  };                                                                                                                   // 11
  projectDef.count = "$count";                                                                                         // 12
                                                                                                                       //
  if (args.errorType) {                                                                                                // 13
    query["value.type"] = args.errorType;                                                                              // 14
  }                                                                                                                    // 15
                                                                                                                       //
  if (args.searchq) {                                                                                                  // 17
    var nameQuery = new RegExp(args.searchq.trim(), "i");                                                              // 18
    query["value.name"] = nameQuery;                                                                                   // 19
  }                                                                                                                    // 20
                                                                                                                       //
  switch (args.sortBy) {                                                                                               // 22
    case "count":                                                                                                      // 23
      sortDef.count = -1;                                                                                              // 24
      break;                                                                                                           // 25
                                                                                                                       //
    case "lastSeenTime":                                                                                               // 26
      groupDef.lastSeenTime = {                                                                                        // 27
        "$max": "$value.startTime"                                                                                     // 27
      };                                                                                                               // 27
      projectDef.lastSeenTime = "$lastSeenTime";                                                                       // 28
      sortDef.lastSeenTime = -1;                                                                                       // 29
      break;                                                                                                           // 30
                                                                                                                       //
    default:                                                                                                           // 31
      sortDef.count = -1;                                                                                              // 32
  }                                                                                                                    // 22
                                                                                                                       //
  pipes.push({                                                                                                         // 35
    $match: query                                                                                                      // 35
  });                                                                                                                  // 35
  pipes.push({                                                                                                         // 36
    $group: groupDef                                                                                                   // 36
  });                                                                                                                  // 36
  pipes.push({                                                                                                         // 37
    $project: projectDef                                                                                               // 37
  });                                                                                                                  // 37
  pipes.push({                                                                                                         // 38
    $sort: sortDef                                                                                                     // 38
  });                                                                                                                  // 38
  pipes.push({                                                                                                         // 39
    $limit: 50                                                                                                         // 39
  });                                                                                                                  // 39
  return pipes;                                                                                                        // 40
}, [KadiraErrorFilters.filterErrorsByStatus()]);                                                                       // 41
KadiraData.defineMetrics("timeseries.errors", "errorMetrics", function (args) {                                        // 45
  var query = args.query;                                                                                              // 48
  var selectedError = args.selection; // start - filter by error status                                                // 50
                                                                                                                       //
  var range = args.range || 30 * 60 * 1000;                                                                            // 53
                                                                                                                       //
  var resolution = KadiraData._CalculateResolutionForRange(range); // args.searchq and args.errorType is already filtered by hbarData
  // selectedError can include "" values too                                                                           // 57
                                                                                                                       //
                                                                                                                       //
  if (selectedError !== undefined) {                                                                                   // 58
    query["value.name"] = selectedError;                                                                               // 59
  }                                                                                                                    // 60
                                                                                                                       //
  var hbarData = KadiraData.getMetrics("breakdown.errors", args, resolution, range);                                   // 61
                                                                                                                       //
  if (hbarData.length > 0) {                                                                                           // 64
    query["$or"] = [];                                                                                                 // 65
    hbarData.forEach(function (d) {                                                                                    // 66
      query["$or"].push({                                                                                              // 67
        "value.name": d._id.name,                                                                                      // 67
        "value.type": d._id.type                                                                                       // 67
      });                                                                                                              // 67
    });                                                                                                                // 68
  } else {                                                                                                             // 69
    // empty hbar data means chart should be empty too                                                                 // 70
    query["value.name"] = null;                                                                                        // 71
  } // end - filter by error status                                                                                    // 72
                                                                                                                       //
                                                                                                                       //
  var pipes = [];                                                                                                      // 77
  pipes.push({                                                                                                         // 78
    $match: query                                                                                                      // 78
  });                                                                                                                  // 78
  pipes.push({                                                                                                         // 79
    $group: buildGroup()                                                                                               // 79
  });                                                                                                                  // 79
  pipes.push({                                                                                                         // 80
    $project: {                                                                                                        // 80
      _id: "$_id",                                                                                                     // 81
      errorCount: "$errorCount"                                                                                        // 82
    }                                                                                                                  // 80
  });                                                                                                                  // 80
  pipes.push({                                                                                                         // 84
    $sort: {                                                                                                           // 84
      _id: 1                                                                                                           // 84
    }                                                                                                                  // 84
  });                                                                                                                  // 84
                                                                                                                       //
  function buildGroup() {                                                                                              // 86
    var groupDef = {                                                                                                   // 87
      _id: {                                                                                                           // 87
        time: "$value.startTime"                                                                                       // 87
      }                                                                                                                // 87
    };                                                                                                                 // 87
    groupDef.errorCount = {                                                                                            // 89
      "$sum": "$value.count"                                                                                           // 89
    };                                                                                                                 // 89
    return groupDef;                                                                                                   // 90
  }                                                                                                                    // 91
                                                                                                                       //
  return pipes;                                                                                                        // 92
}, [KadiraDataFilters.addZeros(["errorCount"])]);                                                                      // 93
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"histograms.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/histograms.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("histogram.pubsub", "pubMetrics", function (args) {                                           // 1
  var pipes = [];                                                                                                      // 2
  var query = args.query; // we need to get the 1min resoution always                                                  // 3
                                                                                                                       //
  query["value.res"] = "1min";                                                                                         // 6
                                                                                                                       //
  var actualRes = KadiraData._CalculateResolutionForRange(args.range);                                                 // 7
                                                                                                                       //
  var resMillis = KadiraData._ResolutionToMillis(actualRes);                                                           // 8
                                                                                                                       //
  query["value.startTime"] = {                                                                                         // 9
    $gte: args.time,                                                                                                   // 10
    $lt: new Date(args.time.getTime() + resMillis)                                                                     // 11
  };                                                                                                                   // 9
  var selectedPublication = args.selection;                                                                            // 14
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 15
    query["value.pub"] = selectedPublication;                                                                          // 16
  }                                                                                                                    // 17
                                                                                                                       //
  pipes.push({                                                                                                         // 19
    $match: args.query                                                                                                 // 19
  });                                                                                                                  // 19
  pipes.push({                                                                                                         // 20
    $project: {                                                                                                        // 20
      "bin": {                                                                                                         // 21
        $subtract: ["$value.resTime", {                                                                                // 21
          $mod: ["$value.resTime", 100]                                                                                // 21
        }]                                                                                                             // 21
      },                                                                                                               // 21
      "subs": "$value.subs"                                                                                            // 22
    }                                                                                                                  // 20
  });                                                                                                                  // 20
  pipes.push({                                                                                                         // 24
    $group: {                                                                                                          // 24
      _id: "$bin",                                                                                                     // 25
      count: {                                                                                                         // 26
        $sum: "$subs"                                                                                                  // 26
      }                                                                                                                // 26
    }                                                                                                                  // 24
  });                                                                                                                  // 24
  pipes.push({                                                                                                         // 28
    $sort: {                                                                                                           // 28
      "_id": 1                                                                                                         // 28
    }                                                                                                                  // 28
  });                                                                                                                  // 28
  return pipes;                                                                                                        // 30
});                                                                                                                    // 31
KadiraData.defineMetrics("histogram.method", "methodsMetrics", function (args) {                                       // 33
  var pipes = [];                                                                                                      // 34
  var query = args.query; // we need to get the 1min resoution always                                                  // 35
                                                                                                                       //
  query["value.res"] = "1min";                                                                                         // 38
                                                                                                                       //
  var actualRes = KadiraData._CalculateResolutionForRange(args.range);                                                 // 39
                                                                                                                       //
  var resMillis = KadiraData._ResolutionToMillis(actualRes);                                                           // 40
                                                                                                                       //
  query["value.startTime"] = {                                                                                         // 41
    $gte: args.time,                                                                                                   // 42
    $lt: new Date(args.time.getTime() + resMillis)                                                                     // 43
  };                                                                                                                   // 41
  var selectedPublication = args.selection;                                                                            // 46
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 47
    query["value.name"] = selectedPublication;                                                                         // 48
  }                                                                                                                    // 49
                                                                                                                       //
  pipes.push({                                                                                                         // 51
    $match: args.query                                                                                                 // 51
  });                                                                                                                  // 51
  pipes.push({                                                                                                         // 52
    $project: {                                                                                                        // 52
      "bin": {                                                                                                         // 53
        $subtract: ["$value.total", {                                                                                  // 53
          $mod: ["$value.total", 100]                                                                                  // 53
        }]                                                                                                             // 53
      },                                                                                                               // 53
      "count": "$value.count"                                                                                          // 54
    }                                                                                                                  // 52
  });                                                                                                                  // 52
  pipes.push({                                                                                                         // 56
    $group: {                                                                                                          // 56
      _id: "$bin",                                                                                                     // 57
      count: {                                                                                                         // 58
        $sum: "$count"                                                                                                 // 58
      }                                                                                                                // 58
    }                                                                                                                  // 56
  });                                                                                                                  // 56
  pipes.push({                                                                                                         // 60
    $sort: {                                                                                                           // 60
      "_id": 1                                                                                                         // 60
    }                                                                                                                  // 60
  });                                                                                                                  // 60
  return pipes;                                                                                                        // 62
});                                                                                                                    // 63
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"summary.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/summary.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineMetrics("summary.pubsub", "pubMetrics", function (args) {                                             // 1
  var query = args.query;                                                                                              // 2
  var selectedPublication = args.selection;                                                                            // 4
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 5
    query["value.pub"] = selectedPublication;                                                                          // 6
  }                                                                                                                    // 7
                                                                                                                       //
  var pipes = [];                                                                                                      // 9
  var projectDef = {};                                                                                                 // 10
  var groupDef = {                                                                                                     // 11
    _id: null                                                                                                          // 11
  };                                                                                                                   // 11
  groupDef.subs = {                                                                                                    // 13
    "$sum": "$value.subs"                                                                                              // 13
  };                                                                                                                   // 13
  projectDef.subs = "$subs";                                                                                           // 14
  groupDef.resTime = {                                                                                                 // 16
    "$sum": KadiraDataHelpers.safeMultiply("$value.resTime", "$value.subs")                                            // 17
  };                                                                                                                   // 16
  projectDef.resTime = KadiraDataHelpers.divideWithZero("$resTime", "$subs", true);                                    // 19
  pipes.push({                                                                                                         // 22
    $match: query                                                                                                      // 22
  });                                                                                                                  // 22
  pipes.push({                                                                                                         // 23
    $group: groupDef                                                                                                   // 23
  });                                                                                                                  // 23
  pipes.push({                                                                                                         // 24
    $project: projectDef                                                                                               // 24
  });                                                                                                                  // 24
  return pipes;                                                                                                        // 26
}, [KadiraDataFilters.divideByRange(["subs"]), KadiraDataFilters.roundTo(["subs"], 2), KadiraDataFilters.roundTo(["resTime"], 0)]);
KadiraData.defineMetrics("summary.liveQueries", "pubMetrics", function (args) {                                        // 33
  var query = args.query;                                                                                              // 34
  var selectedPublication = args.selection;                                                                            // 36
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 37
    query["value.pub"] = selectedPublication;                                                                          // 38
  }                                                                                                                    // 39
                                                                                                                       //
  var pipes = [];                                                                                                      // 41
  var projectDef = {};                                                                                                 // 42
  var groupDef = {                                                                                                     // 43
    _id: null                                                                                                          // 43
  };                                                                                                                   // 43
  groupDef.subs = {                                                                                                    // 45
    "$sum": "$value.subs"                                                                                              // 45
  };                                                                                                                   // 45
  projectDef.subs = "$subs";                                                                                           // 46
  groupDef.lifeTime = {                                                                                                // 48
    "$avg": "$value.lifeTime"                                                                                          // 48
  };                                                                                                                   // 48
  projectDef.lifeTime = "$lifeTime";                                                                                   // 49
  groupDef.polledDocuments = {                                                                                         // 51
    "$sum": "$value.polledDocuments"                                                                                   // 51
  };                                                                                                                   // 51
  projectDef.polledDocuments = "$polledDocuments";                                                                     // 52
  var liveUpdatesFields = ["$value.liveAddedDocuments", "$value.liveChangedDocuments", "$value.liveRemovedDocuments"];
  groupDef.liveUpdates = {                                                                                             // 59
    "$sum": {                                                                                                          // 59
      "$add": liveUpdatesFields                                                                                        // 59
    }                                                                                                                  // 59
  };                                                                                                                   // 59
  projectDef.liveUpdates = "$liveUpdates";                                                                             // 60
  groupDef.initiallyAddedDocuments = {                                                                                 // 62
    "$sum": "$value.initiallyAddedDocuments"                                                                           // 62
  };                                                                                                                   // 62
  var allDocumentChangesFields = ["$value.liveAddedDocuments", "$value.liveChangedDocuments", "$value.liveRemovedDocuments"];
  groupDef.allDocumentChanges = {                                                                                      // 67
    "$sum": {                                                                                                          // 67
      $add: allDocumentChangesFields                                                                                   // 67
    }                                                                                                                  // 67
  };                                                                                                                   // 67
  projectDef.updateRatio = KadiraDataHelpers.safeMultiply(KadiraDataHelpers.divideWithZero("$allDocumentChanges", "$initiallyAddedDocuments", true), 100);
  groupDef.resTime = {                                                                                                 // 75
    "$sum": KadiraDataHelpers.safeMultiply("$value.resTime", "$value.subs")                                            // 76
  };                                                                                                                   // 75
  projectDef.resTime = KadiraDataHelpers.divideWithZero("$resTime", "$subs", true);                                    // 78
  groupDef.totalObserverHandlers = {                                                                                   // 81
    "$sum": "$value.totalObserverHandlers"                                                                             // 81
  };                                                                                                                   // 81
  groupDef.cachedObservers = {                                                                                         // 82
    "$sum": "$value.cachedObservers"                                                                                   // 82
  };                                                                                                                   // 82
  projectDef.observerReuse = KadiraDataHelpers.safeMultiply(KadiraDataHelpers.divideWithZero("$cachedObservers", "$totalObserverHandlers", true), 100);
  pipes.push({                                                                                                         // 89
    $match: query                                                                                                      // 89
  });                                                                                                                  // 89
  pipes.push({                                                                                                         // 90
    $group: groupDef                                                                                                   // 90
  });                                                                                                                  // 90
  pipes.push({                                                                                                         // 91
    $project: projectDef                                                                                               // 91
  });                                                                                                                  // 91
  return pipes;                                                                                                        // 93
}, [KadiraDataFilters.divideByRange(["subs"]), KadiraDataFilters.roundTo(["observerReuse", "updateRatio"], 2), KadiraDataFilters.roundTo(["resTime", "lifeTime", "polledDocuments", "changedDocuments"], 0)]);
KadiraData.defineMetrics("summary.activeSubs", "pubMetrics", function (args) {                                         // 101
  var query = args.query;                                                                                              // 102
  var selectedPublication = args.selection;                                                                            // 104
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 105
    query["value.pub"] = selectedPublication;                                                                          // 106
  }                                                                                                                    // 107
                                                                                                                       //
  var pipes = [];                                                                                                      // 109
  var preGroupDef = {                                                                                                  // 111
    _id: {                                                                                                             // 112
      pub: "$value.pub",                                                                                               // 112
      host: "$value.host"                                                                                              // 112
    },                                                                                                                 // 112
    activeSubs: {                                                                                                      // 113
      "$avg": "$value.activeSubs"                                                                                      // 114
    }                                                                                                                  // 113
  };                                                                                                                   // 111
  var postGroupDef = {                                                                                                 // 118
    _id: null,                                                                                                         // 119
    activeSubs: {                                                                                                      // 120
      "$sum": "$activeSubs"                                                                                            // 121
    }                                                                                                                  // 120
  };                                                                                                                   // 118
  var postProjectDef = {                                                                                               // 124
    activeSubs: "$activeSubs"                                                                                          // 124
  };                                                                                                                   // 124
  pipes.push({                                                                                                         // 126
    $match: query                                                                                                      // 126
  });                                                                                                                  // 126
  pipes.push({                                                                                                         // 127
    $group: preGroupDef                                                                                                // 127
  });                                                                                                                  // 127
  pipes.push({                                                                                                         // 128
    $group: postGroupDef                                                                                               // 128
  });                                                                                                                  // 128
  pipes.push({                                                                                                         // 129
    $project: postProjectDef                                                                                           // 129
  });                                                                                                                  // 129
  return pipes;                                                                                                        // 131
}, [KadiraDataFilters.roundTo(["activeSubs"], 2)]);                                                                    // 132
KadiraData.defineMetrics("summary.methods", "methodsMetrics", function (args) {                                        // 136
  var query = args.query;                                                                                              // 137
  var selectedPublication = args.selection;                                                                            // 139
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 140
    query["value.name"] = selectedPublication;                                                                         // 141
  }                                                                                                                    // 142
                                                                                                                       //
  var pipes = [];                                                                                                      // 144
  var projectDef = {};                                                                                                 // 145
  var groupDef = {                                                                                                     // 146
    _id: null                                                                                                          // 146
  };                                                                                                                   // 146
  groupDef.count = {                                                                                                   // 148
    "$sum": "$value.count"                                                                                             // 148
  };                                                                                                                   // 148
  projectDef.count = "$count";                                                                                         // 149
  groupDef.methodResTime = {                                                                                           // 151
    "$sum": KadiraDataHelpers.safeMultiply("$value.total", "$value.count")                                             // 152
  };                                                                                                                   // 151
  projectDef.methodResTime = KadiraDataHelpers.divideWithZero("$methodResTime", "$count", true);                       // 154
  groupDef.throughput = {                                                                                              // 157
    "$sum": "$value.count"                                                                                             // 157
  };                                                                                                                   // 157
  projectDef.throughput = "$throughput";                                                                               // 158
  pipes.push({                                                                                                         // 160
    $match: query                                                                                                      // 160
  });                                                                                                                  // 160
  pipes.push({                                                                                                         // 161
    $group: groupDef                                                                                                   // 161
  });                                                                                                                  // 161
  pipes.push({                                                                                                         // 162
    $project: projectDef                                                                                               // 162
  });                                                                                                                  // 162
  return pipes;                                                                                                        // 164
}, [KadiraDataFilters.divideByRange(["throughput"]), KadiraDataFilters.roundTo(["throughput", "count"], 2), KadiraDataFilters.roundTo(["methodResTime"], 0)]);
KadiraData.defineMetrics("summary.system", "systemMetrics", function (args) {                                          // 171
  var query = args.query;                                                                                              // 172
  var pipes = [];                                                                                                      // 173
  var projectDef = {};                                                                                                 // 174
  var groupDef = {                                                                                                     // 175
    _id: null                                                                                                          // 175
  };                                                                                                                   // 175
  groupDef.memory = {                                                                                                  // 177
    $avg: "$value.memory"                                                                                              // 177
  };                                                                                                                   // 177
  projectDef.memory = "$memory";                                                                                       // 178
  groupDef.pcpu = {                                                                                                    // 180
    $avg: "$value.pcpu"                                                                                                // 180
  };                                                                                                                   // 180
  projectDef.pcpu = "$pcpu";                                                                                           // 181
  groupDef.sessions = {                                                                                                // 183
    $avg: "$value.sessions"                                                                                            // 183
  };                                                                                                                   // 183
  projectDef.sessions = "$sessions";                                                                                   // 184
  pipes.push({                                                                                                         // 186
    $match: query                                                                                                      // 186
  });                                                                                                                  // 186
  pipes.push({                                                                                                         // 187
    $group: groupDef                                                                                                   // 187
  });                                                                                                                  // 187
  pipes.push({                                                                                                         // 188
    $project: projectDef                                                                                               // 188
  });                                                                                                                  // 188
  return pipes;                                                                                                        // 189
}, [KadiraDataFilters.roundTo(["memory", "pcpu"], 2), KadiraDataFilters.roundTo(["sessions"], 0)]);                    // 190
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"traces.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/kadira_data_definitions/traces.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraData.defineTraces("traces.pubsubList", "pubTraces", function (args) {                                            // 1
  var limit = args.limit || 5;                                                                                         // 2
  var pipes = [];                                                                                                      // 3
  var query = args.query;                                                                                              // 4
  var sortPipe = {                                                                                                     // 6
    "totalValue": -1                                                                                                   // 6
  };                                                                                                                   // 6
  var selectedPublication = args.selection;                                                                            // 8
                                                                                                                       //
  if (selectedPublication) {                                                                                           // 9
    query["name"] = selectedPublication;                                                                               // 10
  }                                                                                                                    // 11
                                                                                                                       //
  if (args.from >= 0) {                                                                                                // 13
    query["totalValue"] = query["totalValue"] || {};                                                                   // 14
    query["totalValue"]["$gte"] = args.from;                                                                           // 15
    sortPipe["totalValue"] = 1;                                                                                        // 16
  }                                                                                                                    // 17
                                                                                                                       //
  if (args.to) {                                                                                                       // 19
    query["totalValue"] = query["totalValue"] || {};                                                                   // 20
    query["totalValue"]["$lt"] = args.to;                                                                              // 21
  }                                                                                                                    // 22
                                                                                                                       //
  pipes.push({                                                                                                         // 24
    $match: args.query                                                                                                 // 24
  });                                                                                                                  // 24
  pipes.push({                                                                                                         // 25
    $sort: sortPipe                                                                                                    // 25
  });                                                                                                                  // 25
  pipes.push({                                                                                                         // 26
    $limit: limit                                                                                                      // 26
  });                                                                                                                  // 26
  pipes.push({                                                                                                         // 27
    $project: {                                                                                                        // 27
      _id: "$_id",                                                                                                     // 28
      host: "$host",                                                                                                   // 29
      name: "$name",                                                                                                   // 30
      type: "$type",                                                                                                   // 31
      errored: "$errored",                                                                                             // 32
      totalValue: "$totalValue",                                                                                       // 33
      startTime: "$startTime"                                                                                          // 34
    }                                                                                                                  // 27
  });                                                                                                                  // 27
  return pipes;                                                                                                        // 37
});                                                                                                                    // 38
KadiraData.defineTraces("traces.pubsubSingle", "pubTraces", function (args) {                                          // 40
  KadiraDataHelpers.removeExpireFlag("pubTraces", args.query.appId, args.query._id);                                   // 41
  var pipes = [];                                                                                                      // 44
  pipes.push({                                                                                                         // 46
    $match: args.query                                                                                                 // 46
  });                                                                                                                  // 46
  pipes.push({                                                                                                         // 47
    $limit: 1                                                                                                          // 47
  });                                                                                                                  // 47
  return pipes;                                                                                                        // 48
}, [KadiraDataFilters.decriptTrace]);                                                                                  // 49
KadiraData.defineTraces("traces.methodsList", "methodTraces", function (args) {                                        // 51
  var limit = args.limit || 5;                                                                                         // 52
  var pipes = [];                                                                                                      // 53
  var query = args.query;                                                                                              // 54
  var sortPipe = {                                                                                                     // 56
    "totalValue": -1                                                                                                   // 56
  };                                                                                                                   // 56
  var selectedMethod = args.selection;                                                                                 // 58
                                                                                                                       //
  if (selectedMethod) {                                                                                                // 59
    query["name"] = selectedMethod;                                                                                    // 60
  }                                                                                                                    // 61
                                                                                                                       //
  if (args.from >= 0) {                                                                                                // 63
    query["totalValue"] = query["totalValue"] || {};                                                                   // 64
    query["totalValue"]["$gte"] = args.from;                                                                           // 65
    sortPipe["totalValue"] = 1;                                                                                        // 66
  }                                                                                                                    // 67
                                                                                                                       //
  if (args.to) {                                                                                                       // 69
    query["totalValue"] = query["totalValue"] || {};                                                                   // 70
    query["totalValue"]["$lt"] = args.to;                                                                              // 71
  }                                                                                                                    // 72
                                                                                                                       //
  pipes.push({                                                                                                         // 74
    $match: args.query                                                                                                 // 74
  });                                                                                                                  // 74
  pipes.push({                                                                                                         // 75
    $sort: sortPipe                                                                                                    // 75
  });                                                                                                                  // 75
  pipes.push({                                                                                                         // 76
    $limit: limit                                                                                                      // 76
  });                                                                                                                  // 76
  pipes.push({                                                                                                         // 77
    $project: {                                                                                                        // 77
      _id: "$_id",                                                                                                     // 78
      host: "$host",                                                                                                   // 79
      name: "$name",                                                                                                   // 80
      type: "$type",                                                                                                   // 81
      errored: "$errored",                                                                                             // 82
      totalValue: "$totalValue",                                                                                       // 83
      startTime: "$startTime"                                                                                          // 84
    }                                                                                                                  // 77
  });                                                                                                                  // 77
  return pipes;                                                                                                        // 87
});                                                                                                                    // 88
KadiraData.defineTraces("traces.methodsSingle", "methodTraces", function (args) {                                      // 90
  KadiraDataHelpers.removeExpireFlag("methodTraces", args.query.appId, args.query._id);                                // 91
  var pipes = [];                                                                                                      // 94
  pipes.push({                                                                                                         // 96
    $match: args.query                                                                                                 // 96
  });                                                                                                                  // 96
  pipes.push({                                                                                                         // 97
    $limit: 1                                                                                                          // 97
  });                                                                                                                  // 97
  return pipes;                                                                                                        // 99
}, [KadiraDataFilters.decriptTrace]);                                                                                  // 100
KadiraData.defineTraces("traces.errorsSingle", "errorTraces", function (args) {                                        // 103
  KadiraDataHelpers.removeExpireFlag("errorTraces", args.query.appId, args.query._id);                                 // 104
  var pipes = [];                                                                                                      // 107
  pipes.push({                                                                                                         // 109
    $match: args.query                                                                                                 // 109
  });                                                                                                                  // 109
  pipes.push({                                                                                                         // 110
    $limit: 1                                                                                                          // 110
  });                                                                                                                  // 110
  return pipes;                                                                                                        // 112
}, [KadiraDataFilters.decriptTrace]);                                                                                  // 113
KadiraData.defineTraces("traces.errorsList", "errorTraces", function (args) {                                          // 115
  var limit = args.limit || 20;                                                                                        // 116
  var pipes = [];                                                                                                      // 117
  var query = args.query;                                                                                              // 118
  var groupDef = {};                                                                                                   // 119
  var projectDef = {};                                                                                                 // 120
  var selectedError = args.selection;                                                                                  // 122
                                                                                                                       //
  if (args.searchq) {                                                                                                  // 123
    var nameQuery = new RegExp(args.searchq.trim(), "i");                                                              // 124
    query["name"] = nameQuery;                                                                                         // 125
  } // selectedError can include "" values too                                                                         // 126
                                                                                                                       //
                                                                                                                       //
  if (selectedError !== undefined) {                                                                                   // 129
    query["name"] = selectedError;                                                                                     // 130
  }                                                                                                                    // 131
                                                                                                                       //
  if (args.errorType) {                                                                                                // 133
    query["type"] = args.errorType;                                                                                    // 134
  }                                                                                                                    // 135
                                                                                                                       //
  groupDef._id = {                                                                                                     // 138
    name: "$name",                                                                                                     // 138
    type: "$type"                                                                                                      // 138
  };                                                                                                                   // 138
  groupDef.values = {                                                                                                  // 139
    $push: {                                                                                                           // 139
      id: "$_id",                                                                                                      // 139
      time: "$startTime"                                                                                               // 139
    }                                                                                                                  // 139
  };                                                                                                                   // 139
  projectDef.name = "$_id.name";                                                                                       // 141
  projectDef.type = "$_id.type";                                                                                       // 142
  projectDef.samples = "$values";                                                                                      // 143
  pipes.push({                                                                                                         // 146
    $match: query                                                                                                      // 146
  });                                                                                                                  // 146
  pipes.push({                                                                                                         // 147
    $group: groupDef                                                                                                   // 147
  });                                                                                                                  // 147
  pipes.push({                                                                                                         // 148
    $project: projectDef                                                                                               // 148
  });                                                                                                                  // 148
  pipes.push({                                                                                                         // 149
    $limit: limit                                                                                                      // 149
  });                                                                                                                  // 149
  return pipes;                                                                                                        // 151
}, [KadiraDataFilters.convertObjectToId, KadiraDataFilters.limitSamples(5)]);                                          // 152
KadiraData.defineTraces("traces.traceSample", "errorTraces", function (args) {                                         // 158
  var pipes = [];                                                                                                      // 159
  var query = args.query;                                                                                              // 160
  var range = args.range || 30 * 60 * 1000;                                                                            // 162
                                                                                                                       //
  var resolution = KadiraData._CalculateResolutionForRange(range);                                                     // 163
                                                                                                                       //
  if (args.realtime) {                                                                                                 // 165
    query.startTime = KadiraData._CalulateRealtimeDateRange(resolution, range);                                        // 166
  } else {                                                                                                             // 168
    query.startTime = KadiraData._CalculateDateRange(args.time, range);                                                // 169
  }                                                                                                                    // 171
                                                                                                                       //
  var selectedError = args.selection;                                                                                  // 173
                                                                                                                       //
  if (args.searchq) {                                                                                                  // 174
    var nameQuery = new RegExp(args.searchq.trim(), "i");                                                              // 175
    query["name"] = nameQuery;                                                                                         // 176
  } // selectedError can include "" values too                                                                         // 177
                                                                                                                       //
                                                                                                                       //
  if (selectedError !== undefined) {                                                                                   // 180
    query["name"] = selectedError;                                                                                     // 181
  }                                                                                                                    // 182
                                                                                                                       //
  if (args.errorType) {                                                                                                // 184
    query["type"] = args.errorType;                                                                                    // 185
  }                                                                                                                    // 186
                                                                                                                       //
  pipes.push({                                                                                                         // 188
    $match: query                                                                                                      // 188
  });                                                                                                                  // 188
  pipes.push({                                                                                                         // 189
    $sort: {                                                                                                           // 189
      startTime: -1                                                                                                    // 189
    }                                                                                                                  // 189
  });                                                                                                                  // 189
  pipes.push({                                                                                                         // 190
    $limit: 1                                                                                                          // 190
  });                                                                                                                  // 190
  return pipes;                                                                                                        // 191
});                                                                                                                    // 192
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"config":{"accounts.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/config/accounts.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Accounts.emailTemplates.siteName = i18n("common.site_name");                                                           // 1
Accounts.emailTemplates.from = "Kadira <no-reply@kadira.io>";                                                          // 2
                                                                                                                       //
Accounts.emailTemplates.resetPassword.subject = function () {                                                          // 3
  return i18n("emails.reset_password_subject");                                                                        // 4
};                                                                                                                     // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"emailConfig.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/config/emailConfig.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
EmailConfig = {};                                                                                                      // 1
EmailConfig.from = {                                                                                                   // 3
  from: "Kadira <no-reply@kadira.io>",                                                                                 // 4
  subject: "Kadira: Performance Monitoring for Meteor"                                                                 // 5
};                                                                                                                     // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"emailTemplates.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/config/emailTemplates.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
EmailTemplates = {};                                                                                                   // 1
var newCollabTmpl = i18n("share.collaborator_invite_email_tmpl");                                                      // 3
EmailTemplates.notifyNewCollaborator = _.template(newCollabTmpl);                                                      // 4
var newOwnerTemp = i18n("share.notify_new_owner_email_templ");                                                         // 6
EmailTemplates.notifyNewOwner = _.template(newOwnerTemp);                                                              // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"rate_limit.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/config/rate_limit.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  if (process.env.METEOR_ENV === "test") {                                                                             // 2
    Accounts.removeDefaultRateLimit();                                                                                 // 3
  }                                                                                                                    // 4
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"security.js":["helmet",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/config/security.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var helmet = void 0;                                                                                                   // 1
module.import('helmet', {                                                                                              // 1
  "default": function (v) {                                                                                            // 1
    helmet = v;                                                                                                        // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
// added HSTS headers                                                                                                  // 3
WebApp.connectHandlers.use(helmet.hsts({                                                                               // 4
  maxAge: 1000 * 3600 * 24 * 30,                                                                                       // 5
  // 30 days,                                                                                                          // 5
  includeSubdomains: false,                                                                                            // 6
  // preven sending HSTS for Kadira Debug                                                                              // 7
  setIf: function (req) {                                                                                              // 8
    var host = req.headers["host"];                                                                                    // 9
                                                                                                                       //
    if (/^debug.kadira.io/.test(host)) {                                                                               // 10
      return false;                                                                                                    // 11
    } else {                                                                                                           // 12
      return true;                                                                                                     // 13
    }                                                                                                                  // 14
  }                                                                                                                    // 15
})); // added iexss                                                                                                    // 4
                                                                                                                       //
WebApp.connectHandlers.use(helmet.xssFilter()); // stop clickjacking                                                   // 19
                                                                                                                       //
WebApp.connectHandlers.use(helmet.frameguard()); // force-ssl                                                          // 22
                                                                                                                       //
WebApp.connectHandlers.use(function (req, res, next) {                                                                 // 25
  // borrowed from: https://goo.gl/PfeRc9                                                                              // 26
  var isSsl = req.connection.pair || req.headers["x-forwarded-proto"] && req.headers["x-forwarded-proto"].indexOf("https") !== -1;
  var host = req.headers["host"]; // borrowed from: https://goo.gl/PfeRc9                                              // 31
  // strip off the port number. If we went to a URL with a custom                                                      // 33
  // port, we don"t know what the custom SSL port is anyway.                                                           // 34
                                                                                                                       //
  host = host.replace(/:\d+$/, "");                                                                                    // 35
  var isKadiraIoHost = /kadira.io/.test(host);                                                                         // 37
                                                                                                                       //
  if (!isSsl && isKadiraIoHost) {                                                                                      // 38
    var newUrl = "https://" + host + req.url;                                                                          // 39
    res.writeHead(302, {                                                                                               // 40
      "Location": newUrl                                                                                               // 41
    });                                                                                                                // 40
    res.end();                                                                                                         // 43
    return;                                                                                                            // 44
  }                                                                                                                    // 45
                                                                                                                       //
  next();                                                                                                              // 47
});                                                                                                                    // 48
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"hooks":{"login.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/hooks/login.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var originalUpdateOrCreateUserFromExternalService = Accounts.updateOrCreateUserFromExternalService;                    // 1
                                                                                                                       //
Accounts.updateOrCreateUserFromExternalService = function (serviceName, serviceData) {                                 // 4
  //if logged in user can add it to his profile                                                                        // 6
  var loggedInUserId = Meteor.userId();                                                                                // 7
                                                                                                                       //
  if (serviceName === "meteor-developer" && loggedInUserId) {                                                          // 8
    if (serviceData && serviceData.id) {                                                                               // 9
      var alreadyConnected = Meteor.users.findOne({                                                                    // 10
        "services.meteor-developer.id": serviceData.id                                                                 // 11
      });                                                                                                              // 10
                                                                                                                       //
      if (alreadyConnected && alreadyConnected._id !== loggedInUserId) {                                               // 13
        throw new Meteor.Error(403, i18n("signIn.already_connected_meteor_dev_account"));                              // 14
      } else {                                                                                                         // 16
        var setAttr = {};                                                                                              // 17
        setAttr["services.meteor-developer"] = serviceData;                                                            // 18
        Meteor.users.update({                                                                                          // 19
          _id: loggedInUserId                                                                                          // 20
        }, {                                                                                                           // 19
          $set: setAttr                                                                                                // 22
        });                                                                                                            // 21
      }                                                                                                                // 24
    }                                                                                                                  // 25
  }                                                                                                                    // 26
                                                                                                                       //
  if (serviceName === "meteor-developer" && !loggedInUserId) {                                                         // 28
    var isConnected = Meteor.users.findOne({                                                                           // 29
      "services.meteor-developer.id": serviceData.id                                                                   // 30
    });                                                                                                                // 29
    var user = getUser(serviceData.emails); /* if meteor developer is not connected and                                // 32
                                              email is registered to a kadira account */                               //
                                                                                                                       //
    if (!isConnected && user) {                                                                                        // 35
      var existingEmail = AccountsHelpers.getUserEmail(user);                                                          // 36
      throw new Meteor.Error(403, i18n("signIn.already_registed_via_email", existingEmail));                           // 37
    }                                                                                                                  // 39
  }                                                                                                                    // 40
                                                                                                                       //
  return originalUpdateOrCreateUserFromExternalService.apply(this, arguments);                                         // 41
};                                                                                                                     // 42
                                                                                                                       //
function getUser(emails) {                                                                                             // 44
  var emailsArray = [];                                                                                                // 45
  emails.forEach(function (emailInfo) {                                                                                // 46
    emailsArray.push(emailInfo.address);                                                                               // 47
  });                                                                                                                  // 48
  return Meteor.users.findOne({                                                                                        // 49
    "emails.address": {                                                                                                // 50
      $in: emailsArray                                                                                                 // 51
    }                                                                                                                  // 50
  });                                                                                                                  // 49
}                                                                                                                      // 54
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"register.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/hooks/register.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 1
  if (Meteor.users.find().count() < 1) {                                                                               // 2
    Accounts.createUser({                                                                                              // 3
      username: 'admin',                                                                                               // 4
      email: 'admin@gmail.com',                                                                                        // 5
      password: 'admin'                                                                                                // 6
    });                                                                                                                // 3
    console.log('CREATED ADMIN USER (admin@gmail.com/admin). CHANGE PASSWORD');                                        // 9
  }                                                                                                                    // 10
                                                                                                                       //
  Accounts.onCreateUser(function () {                                                                                  // 12
    throw new Error('Access Denied');                                                                                  // 13
  });                                                                                                                  // 14
});                                                                                                                    // 15
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"account.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/account.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
KadiraAccounts = {};                                                                                                   // 1
                                                                                                                       //
KadiraAccounts.updateAppPlan = function (userId, newPlan, oldPlan) {                                                   // 3
  var query = {                                                                                                        // 4
    owner: userId                                                                                                      // 4
  };                                                                                                                   // 4
  var fields = {                                                                                                       // 5
    "plan": newPlan                                                                                                    // 5
  }; //upgraded from free plan to paid.                                                                                // 5
  // move their paid apps to paid                                                                                      // 8
                                                                                                                       //
  if (oldPlan === "free" && newPlan !== "free") {                                                                      // 9
    fields.pricingType = "paid";                                                                                       // 10
  } else if (oldPlan !== "free" && newPlan === "free") {                                                               // 11
    // user is moving to free plan from a paid plan.                                                                   // 12
    // move their paid apps to free                                                                                    // 13
    fields.pricingType = "free";                                                                                       // 14
  }                                                                                                                    // 15
                                                                                                                       //
  return Apps.update(query, {                                                                                          // 17
    $set: fields                                                                                                       // 17
  }, {                                                                                                                 // 17
    multi: true                                                                                                        // 17
  });                                                                                                                  // 17
};                                                                                                                     // 18
                                                                                                                       //
KadiraAccounts._getMedianHostCount = function (hostUsageByTime, noDataCount) {                                         // 20
  hostUsageByTime = hostUsageByTime || [];                                                                             // 21
                                                                                                                       //
  if (hostUsageByTime.length === 0) {                                                                                  // 22
    return 0;                                                                                                          // 23
  }                                                                                                                    // 24
                                                                                                                       //
  var values = _.chain(hostUsageByTime).pluck("count").sortBy(function (num) {                                         // 25
    return num;                                                                                                        // 27
  }).value();                                                                                                          // 27
                                                                                                                       //
  var missingDataArr = Array(noDataCount).fill(0);                                                                     // 29
  values = missingDataArr.concat(values);                                                                              // 30
  var half = Math.floor(values.length / 2);                                                                            // 32
  var median;                                                                                                          // 33
                                                                                                                       //
  if (values.length % 2) {                                                                                             // 34
    median = values[half];                                                                                             // 35
  } else {                                                                                                             // 36
    median = (values[half - 1] + values[half]) / 2;                                                                    // 37
  }                                                                                                                    // 38
                                                                                                                       //
  return Math.floor(median);                                                                                           // 39
};                                                                                                                     // 40
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/apps.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*eslint-disable new-cap*/Meteor.methods({                                                                             // 1
  "apps.create": function (appName, pricingType) {                                                                     // 3
    check(appName, String);                                                                                            // 4
    check(pricingType, Match.OneOf("free", "paid"));                                                                   // 5
    Validations.checkAppName(appName);                                                                                 // 6
                                                                                                                       //
    if (!this.userId) {                                                                                                // 8
      throw new Meteor.Error(403, "user must login to create app");                                                    // 9
    } // set users plan to app                                                                                         // 10
                                                                                                                       //
                                                                                                                       //
    var plan = getPlanForApp(pricingType);                                                                             // 12
    var shard = KadiraData.mongoCluster.pickShard();                                                                   // 13
    var subShard = Math.floor(Math.random() * 128);                                                                    // 14
    var app = {                                                                                                        // 16
      name: appName,                                                                                                   // 17
      created: new Date(),                                                                                             // 18
      owner: this.userId,                                                                                              // 19
      secret: Meteor.uuid(),                                                                                           // 20
      plan: plan,                                                                                                      // 21
      shard: shard,                                                                                                    // 22
      subShard: subShard,                                                                                              // 23
      pricingType: pricingType                                                                                         // 24
    };                                                                                                                 // 16
    return Apps.insert(app);                                                                                           // 27
  },                                                                                                                   // 28
  "apps.updateName": function (appId, appName) {                                                                       // 29
    check(appId, String);                                                                                              // 30
    check(appName, String);                                                                                            // 31
    Validations.checkAppName(appName);                                                                                 // 32
    Apps.update({                                                                                                      // 33
      _id: appId,                                                                                                      // 33
      owner: this.userId                                                                                               // 33
    }, {                                                                                                               // 33
      $set: {                                                                                                          // 33
        name: appName                                                                                                  // 33
      }                                                                                                                // 33
    });                                                                                                                // 33
  },                                                                                                                   // 34
  "apps.regenerateSecret": function (appId) {                                                                          // 35
    check(appId, String);                                                                                              // 36
    var appSecret = Meteor.uuid();                                                                                     // 37
    Apps.update({                                                                                                      // 38
      _id: appId,                                                                                                      // 38
      owner: this.userId                                                                                               // 38
    }, {                                                                                                               // 38
      $set: {                                                                                                          // 38
        secret: appSecret                                                                                              // 38
      }                                                                                                                // 38
    });                                                                                                                // 38
  },                                                                                                                   // 39
  "apps.delete": function (appId) {                                                                                    // 40
    check(appId, String);                                                                                              // 41
    Apps.remove({                                                                                                      // 42
      _id: appId,                                                                                                      // 42
      owner: this.userId                                                                                               // 42
    });                                                                                                                // 42
  },                                                                                                                   // 43
  "apps.updatePricingType": function (appId, pricingType) {                                                            // 44
    check(pricingType, Match.OneOf("free", "paid"));                                                                   // 45
    check(appId, String);                                                                                              // 46
    var currentUserId = Meteor.userId();                                                                               // 47
                                                                                                                       //
    if (!currentUserId) {                                                                                              // 48
      throw new Meteor.Error(403, "You must login to update pricing");                                                 // 49
    }                                                                                                                  // 50
                                                                                                                       //
    var app = Apps.findOne({                                                                                           // 52
      _id: appId                                                                                                       // 52
    }, {                                                                                                               // 52
      owner: 1,                                                                                                        // 52
      plan: 1                                                                                                          // 52
    }) || {};                                                                                                          // 52
                                                                                                                       //
    if (pricingType === "free" && app.plan !== "free") {}                                                              // 54
                                                                                                                       //
    if (currentUserId !== app.owner) {                                                                                 // 57
      throw new Meteor.Error(403, "Only app owner can do that");                                                       // 58
    }                                                                                                                  // 59
                                                                                                                       //
    var plan = getPlanForApp(pricingType);                                                                             // 61
    var fields = {                                                                                                     // 62
      pricingType: pricingType,                                                                                        // 62
      plan: plan                                                                                                       // 62
    };                                                                                                                 // 62
    Apps.update({                                                                                                      // 64
      _id: appId                                                                                                       // 64
    }, {                                                                                                               // 64
      $set: fields                                                                                                     // 64
    });                                                                                                                // 64
  }                                                                                                                    // 65
});                                                                                                                    // 2
                                                                                                                       //
function getPlanForApp(pricingType) {                                                                                  // 68
  switch (pricingType) {                                                                                               // 69
    case "free":                                                                                                       // 70
      return "free";                                                                                                   // 71
                                                                                                                       //
    case "paid":                                                                                                       // 72
      return Utils.getPlanFromUser(Meteor.user());                                                                     // 73
                                                                                                                       //
    default:                                                                                                           // 74
      throw new Error("unknown pricing type");                                                                         // 75
  }                                                                                                                    // 69
}                                                                                                                      // 77
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"errorsMeta.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/errorsMeta.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
  "errorsMeta.changeState": function (appId, errorName, errorType, status) {                                           // 2
    check(appId, String);                                                                                              // 3
    check(errorName, String);                                                                                          // 4
    check(errorType, String);                                                                                          // 5
    check(status, String);                                                                                             // 6
                                                                                                                       //
    KadiraData._authorize(this.userId, null, {                                                                         // 7
      appId: [appId]                                                                                                   // 7
    });                                                                                                                // 7
                                                                                                                       //
    return ErrorsMeta.upsert({                                                                                         // 9
      appId: appId,                                                                                                    // 10
      name: errorName,                                                                                                 // 11
      type: errorType                                                                                                  // 12
    }, {                                                                                                               // 9
      $set: {                                                                                                          // 14
        status: status                                                                                                 // 15
      }                                                                                                                // 14
    });                                                                                                                // 13
  }                                                                                                                    // 18
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"insights.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/insights.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var EMAIL_FREQUENCIES = {                                                                                              // 1
  "weekly": "weekly",                                                                                                  // 2
  "daily": "daily",                                                                                                    // 3
  "off": "off"                                                                                                         // 4
};                                                                                                                     // 1
var getPastReports = Meteor.wrapAsync(_getPastReports);                                                                // 6
var EMAIL_FREQUENCIES = {                                                                                              // 8
  "weekly": "weekly",                                                                                                  // 9
  "daily": "daily",                                                                                                    // 10
  "off": "off"                                                                                                         // 11
};                                                                                                                     // 8
Meteor.methods({                                                                                                       // 14
  "insights.updateEmailPref": function (appId, emailFreq, emailList) {                                                 // 15
    check(appId, String);                                                                                              // 16
    check(emailFreq, Match.Any);                                                                                       // 17
    check(emailList, Match.Any);                                                                                       // 18
    emailFreq = EMAIL_FREQUENCIES[emailFreq] || null;                                                                  // 20
    emailList = emailList.split("\n");                                                                                 // 21
    Apps.update({                                                                                                      // 23
      _id: appId                                                                                                       // 23
    }, {                                                                                                               // 23
      $set: {                                                                                                          // 24
        "reports.frequency": emailFreq,                                                                                // 25
        "reports.emails": emailList                                                                                    // 26
      }                                                                                                                // 24
    });                                                                                                                // 23
  },                                                                                                                   // 29
  "insights.updateEmailFreq": function (appId, emailFreq) {                                                            // 31
    check(appId, String);                                                                                              // 32
    check(emailFreq, Match.Any);                                                                                       // 33
    emailFreq = EMAIL_FREQUENCIES[emailFreq] || null;                                                                  // 35
    Apps.update({                                                                                                      // 37
      _id: appId                                                                                                       // 37
    }, {                                                                                                               // 37
      $set: {                                                                                                          // 37
        "reports.frequency": emailFreq                                                                                 // 37
      }                                                                                                                // 37
    });                                                                                                                // 37
    return true;                                                                                                       // 38
  },                                                                                                                   // 39
  "insights.getPastReports": function (appId) {                                                                        // 41
    check(appId, String);                                                                                              // 42
    var app = Apps.findOne({                                                                                           // 43
      _id: appId                                                                                                       // 43
    });                                                                                                                // 43
                                                                                                                       //
    if (!app) {                                                                                                        // 44
      throw new Meteor.Error(500, "App not found");                                                                    // 45
    }                                                                                                                  // 46
                                                                                                                       //
    var reports = getPastReports(appId);                                                                               // 48
    return reports;                                                                                                    // 49
  }                                                                                                                    // 50
});                                                                                                                    // 14
                                                                                                                       //
function _getPastReports(appId, callback) {                                                                            // 53
  var dbConn = KadiraData.getConnectionForApp(appId);                                                                  // 54
  var reports = dbConn.collection("reports");                                                                          // 55
  return reports.find({                                                                                                // 56
    "appId": appId                                                                                                     // 56
  }, {}, {                                                                                                             // 56
    limit: 20,                                                                                                         // 57
    sort: {                                                                                                            // 57
      time: -1                                                                                                         // 58
    }                                                                                                                  // 57
  }).toArray(callback);                                                                                                // 56
}                                                                                                                      // 61
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"traceExplorer.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/traceExplorer.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
  "traceExplorer.getIpLocation": function (ip) {                                                                       // 2
    check(ip, String);                                                                                                 // 3
    this.unblock();                                                                                                    // 4
    Match.test(ip, String);                                                                                            // 5
    var result = HTTP.call("GET", "http://www.geoplugin.net/json.gp", {                                                // 6
      params: {                                                                                                        // 7
        ip: ip                                                                                                         // 8
      }                                                                                                                // 7
    });                                                                                                                // 6
    var parsed;                                                                                                        // 12
                                                                                                                       //
    if (result && result.content) {                                                                                    // 13
      parsed = JSON.parse(result.content);                                                                             // 14
    }                                                                                                                  // 15
                                                                                                                       //
    var isStatusOk = parsed["geoplugin_status"] === 200 || parsed["geoplugin_status"] === 206;                         // 16
                                                                                                                       //
    if (isStatusOk) {                                                                                                  // 19
      var info = _.pick(parsed, "geoplugin_city", "geoplugin_countryName", "geoplugin_latitude", "geoplugin_longitude");
                                                                                                                       //
      return info;                                                                                                     // 27
    }                                                                                                                  // 28
  }                                                                                                                    // 29
});                                                                                                                    // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"publications":{"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/apps.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("apps.userOwned", function () {                                                                         // 1
  this.unblock();                                                                                                      // 2
                                                                                                                       //
  if (this.userId) {                                                                                                   // 3
    return Apps.find({                                                                                                 // 4
      owner: this.userId                                                                                               // 4
    }, {                                                                                                               // 4
      sort: {                                                                                                          // 4
        created: 1                                                                                                     // 4
      }                                                                                                                // 4
    });                                                                                                                // 4
  } else {                                                                                                             // 5
    return this.ready();                                                                                               // 6
  }                                                                                                                    // 7
});                                                                                                                    // 8
Meteor.publish("apps.collaboratored", function () {                                                                    // 10
  this.unblock();                                                                                                      // 11
                                                                                                                       //
  if (this.userId) {                                                                                                   // 12
    return PermissionsMananger.roles.getUserApps(this.userId);                                                         // 13
  } else {                                                                                                             // 14
    return this.ready();                                                                                               // 15
  }                                                                                                                    // 16
});                                                                                                                    // 17
Meteor.publish("apps.pendingUsers", function (appId) {                                                                 // 19
  check(appId, String);                                                                                                // 20
  this.unblock();                                                                                                      // 21
  var isAllowed = PermissionsMananger.roles.isAllowed("manage_collaborators", appId, this.userId);                     // 22
                                                                                                                       //
  if (isAllowed) {                                                                                                     // 24
    return PendingUsers.find({                                                                                         // 25
      app: appId                                                                                                       // 25
    });                                                                                                                // 25
  } else {                                                                                                             // 26
    this.ready();                                                                                                      // 27
  }                                                                                                                    // 28
});                                                                                                                    // 29
Meteor.publish("apps.collaborators", function (appId) {                                                                // 31
  check(appId, String);                                                                                                // 32
  this.unblock();                                                                                                      // 33
  var isAllowed = PermissionsMananger.roles.isAllowed("manage_collaborators", appId, this.userId);                     // 35
                                                                                                                       //
  if (!isAllowed) {                                                                                                    // 38
    return this.ready();                                                                                               // 39
  }                                                                                                                    // 40
                                                                                                                       //
  var app = Apps.findOne({                                                                                             // 42
    _id: appId                                                                                                         // 42
  });                                                                                                                  // 42
                                                                                                                       //
  if (!app) {                                                                                                          // 43
    return this.ready();                                                                                               // 44
  }                                                                                                                    // 45
                                                                                                                       //
  var cursorsArr = [];                                                                                                 // 47
                                                                                                                       //
  if (app) {                                                                                                           // 49
    var collabFields = {                                                                                               // 50
      fields: {                                                                                                        // 51
        emails: 1,                                                                                                     // 52
        apps: 1,                                                                                                       // 53
        "profile.name": 1,                                                                                             // 54
        "services.meteor-developer.emails": 1                                                                          // 55
      }                                                                                                                // 51
    };                                                                                                                 // 50
    var users = PermissionsMananger.roles.usersWithRole(appId, "collaborator");                                        // 58
    cursorsArr.push(Meteor.users.find({                                                                                // 59
      _id: {                                                                                                           // 59
        $in: users                                                                                                     // 59
      }                                                                                                                // 59
    }, collabFields));                                                                                                 // 59
  }                                                                                                                    // 60
                                                                                                                       //
  if (app) {                                                                                                           // 62
    cursorsArr.push(PendingUsers.find({                                                                                // 63
      app: appId                                                                                                       // 63
    }));                                                                                                               // 63
  }                                                                                                                    // 64
                                                                                                                       //
  return cursorsArr;                                                                                                   // 66
});                                                                                                                    // 67
Meteor.publish("apps.admin", function (appId) {                                                                        // 69
  this.unblock();                                                                                                      // 70
  check(appId, String);                                                                                                // 71
  var user = Meteor.users.findOne(this.userId);                                                                        // 72
                                                                                                                       //
  if (user && user.admin) {                                                                                            // 73
    return Apps.find({                                                                                                 // 74
      _id: appId                                                                                                       // 74
    });                                                                                                                // 74
  } else {                                                                                                             // 75
    this.ready();                                                                                                      // 76
  }                                                                                                                    // 77
});                                                                                                                    // 78
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"errorsMeta.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/errorsMeta.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("errorsMeta.single", function (appId, name, type) {                                                     // 1
  check(appId, String);                                                                                                // 2
  check(name, String);                                                                                                 // 3
  check(type, String);                                                                                                 // 4
  this.unblock();                                                                                                      // 5
                                                                                                                       //
  KadiraData._authorize(this.userId, null, {                                                                           // 7
    appId: [appId]                                                                                                     // 7
  });                                                                                                                  // 7
                                                                                                                       //
  return ErrorsMeta.find({                                                                                             // 8
    appId: appId,                                                                                                      // 8
    name: name,                                                                                                        // 8
    type: type                                                                                                         // 8
  });                                                                                                                  // 8
});                                                                                                                    // 9
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"user.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications/user.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publish("user.userInfo", function () {                                                                          // 1
  this.unblock();                                                                                                      // 2
                                                                                                                       //
  if (this.userId) {                                                                                                   // 3
    var userFields = {                                                                                                 // 4
      emails: 1,                                                                                                       // 5
      plan: 1,                                                                                                         // 6
      apps: 1,                                                                                                         // 7
      admin: 1,                                                                                                        // 8
      createdAt: 1,                                                                                                    // 9
      introVideoSeen: 1,                                                                                               // 10
      billingInfo: 1,                                                                                                  // 11
      stripe: 1,                                                                                                       // 12
      "services.meteor-developer.emails": 1                                                                            // 13
    };                                                                                                                 // 4
    return Meteor.users.find({                                                                                         // 15
      _id: this.userId                                                                                                 // 15
    }, {                                                                                                               // 15
      fields: userFields                                                                                               // 15
    });                                                                                                                // 15
  } else {                                                                                                             // 16
    this.ready();                                                                                                      // 17
  }                                                                                                                    // 18
});                                                                                                                    // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"config":{"errorStatuses.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// config/errorStatuses.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
ErrorStatuses = [{                                                                                                     // 1
  value: "new",                                                                                                        // 2
  label: "Status: New"                                                                                                 // 3
}, {                                                                                                                   // 1
  value: "ignored",                                                                                                    // 5
  label: "Status: Ignored"                                                                                             // 6
}, {                                                                                                                   // 4
  value: "fixing",                                                                                                     // 8
  label: "Status: Fixing"                                                                                              // 9
}, {                                                                                                                   // 7
  value: "fixed",                                                                                                      // 11
  label: "Status: Fixed"                                                                                               // 12
}];                                                                                                                    // 10
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"permissions.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// config/permissions.js                                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
PermissionsMananger.defineAction("manage_collaborators", ["owner"]);                                                   // 1
PermissionsMananger.defineAction("data_access", ["collaborator", "owner", "admin"]);                                   // 2
PermissionsMananger.defineAction("profiler", ["collaborator", "owner", "admin"]);                                      // 4
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"plans.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// config/plans.js                                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Features                                                                                                            // 1
PlansManager.defineFeature("coreData", {                                                                               // 3
  all: true                                                                                                            // 3
});                                                                                                                    // 3
PlansManager.defineFeature("hostInfo", {                                                                               // 4
  except: ["free"]                                                                                                     // 4
});                                                                                                                    // 4
PlansManager.defineFeature("shareApps", {                                                                              // 5
  except: ["free", "solo"]                                                                                             // 5
});                                                                                                                    // 5
PlansManager.defineFeature("alerts", {                                                                                 // 6
  all: true                                                                                                            // 6
});                                                                                                                    // 6
PlansManager.defineFeature("remoteProfiling", {                                                                        // 7
  except: ["free"]                                                                                                     // 7
});                                                                                                                    // 7
PlansManager.defineFeature("observerInfo", {                                                                           // 8
  except: ["free"]                                                                                                     // 8
});                                                                                                                    // 8
PlansManager.defineFeature("reports", {                                                                                // 9
  except: ["free"]                                                                                                     // 9
});                                                                                                                    // 9
PlansManager.defineFeature("insights", ["pro", "business"]);                                                           // 10
PlansManager.defineFeature("profiler", {                                                                               // 11
  except: ["free"]                                                                                                     // 11
});                                                                                                                    // 11
PlansManager.defineFeature("errorStatus", {                                                                            // 12
  except: ["free"]                                                                                                     // 12
});                                                                                                                    // 12
PlansManager.defineFeature("resTimeDistribution", {                                                                    // 13
  except: ["free"]                                                                                                     // 13
}); // Configurations                                                                                                  // 13
                                                                                                                       //
PlansManager.setConfig("plansDef", {                                                                                   // 17
  _default: "free",                                                                                                    // 18
  free: {                                                                                                              // 19
    "amount": 0,                                                                                                       // 19
    "hosts": 1                                                                                                         // 19
  },                                                                                                                   // 19
  solo: {                                                                                                              // 20
    "amount": 10,                                                                                                      // 20
    "hosts": 3                                                                                                         // 20
  },                                                                                                                   // 20
  startup: {                                                                                                           // 21
    "amount": 50,                                                                                                      // 21
    "hosts": 5                                                                                                         // 21
  },                                                                                                                   // 21
  pro: {                                                                                                               // 22
    "amount": 150,                                                                                                     // 22
    "hosts": 15                                                                                                        // 22
  },                                                                                                                   // 22
  business: {                                                                                                          // 23
    "amount": 350,                                                                                                     // 23
    "hosts": 45                                                                                                        // 23
  }                                                                                                                    // 23
});                                                                                                                    // 17
PlansManager.setConfig("allowedRange", {                                                                               // 26
  free: 1000 * 3600 * 38,                                                                                              // 27
  // 38 hours                                                                                                          // 27
  solo: 1000 * 3600 * 24 * 4,                                                                                          // 28
  // 4 days                                                                                                            // 28
  startup: 1000 * 3600 * 27 * 15,                                                                                      // 29
  //15 days                                                                                                            // 29
  pro: 1000 * 3600 * 27 * 95,                                                                                          // 30
  // 95 days                                                                                                           // 30
  business: 1000 * 3600 * 27 * 95 // 95 days                                                                           // 31
                                                                                                                       //
});                                                                                                                    // 26
PlansManager.setConfig("sharedUsersPerApp", {                                                                          // 34
  free: 0,                                                                                                             // 35
  solo: 0,                                                                                                             // 36
  startup: 999999,                                                                                                     // 37
  pro: 999999,                                                                                                         // 38
  business: 99999                                                                                                      // 39
});                                                                                                                    // 34
PlansManager.setConfig("alertsPerApp", {                                                                               // 42
  free: 1,                                                                                                             // 43
  solo: 5,                                                                                                             // 44
  startup: 999999,                                                                                                     // 45
  pro: 999999,                                                                                                         // 46
  business: 99999                                                                                                      // 47
});                                                                                                                    // 42
PlansManager.setConfig("maxRange", {                                                                                   // 50
  free: KadiraData.Ranges.getValue("24hour"),                                                                          // 51
  solo: KadiraData.Ranges.getValue("3day"),                                                                            // 52
  startup: KadiraData.Ranges.getValue("7day"),                                                                         // 53
  pro: KadiraData.Ranges.getValue("30day"),                                                                            // 54
  business: KadiraData.Ranges.getValue("30day")                                                                        // 55
});                                                                                                                    // 50
PlansManager.setConfig("supportedReportFrequencies", {                                                                 // 58
  free: [null, "off"],                                                                                                 // 59
  solo: [null, "off", "daily"],                                                                                        // 60
  startup: [null, "off", "daily", "weekly"],                                                                           // 61
  pro: [null, "off", "daily", "weekly"],                                                                               // 62
  business: [null, "off", "daily", "weekly"]                                                                           // 63
});                                                                                                                    // 58
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/i18n/en.js");
require("./lib/accounts_helpers.js");
require("./lib/autourl.js");
require("./lib/collections.js");
require("./lib/router.js");
require("./lib/utils.js");
require("./lib/validations.js");
require("./server/kadira_data_definitions/filters/0filters.js");
require("./server/kadira_data_definitions/filters/errorManager.js");
require("./server/config/accounts.js");
require("./server/config/emailConfig.js");
require("./server/config/emailTemplates.js");
require("./server/config/rate_limit.js");
require("./server/config/security.js");
require("./server/hooks/login.js");
require("./server/hooks/register.js");
require("./server/kadira_data_definitions/0helpers.js");
require("./server/kadira_data_definitions/dashboard.hosts.js");
require("./server/kadira_data_definitions/dashboard.live_queries.js");
require("./server/kadira_data_definitions/dashboard.methods.js");
require("./server/kadira_data_definitions/dashboard.overview.js");
require("./server/kadira_data_definitions/dashboard.pubsub.js");
require("./server/kadira_data_definitions/errors.js");
require("./server/kadira_data_definitions/histograms.js");
require("./server/kadira_data_definitions/summary.js");
require("./server/kadira_data_definitions/traces.js");
require("./server/methods/account.js");
require("./server/methods/apps.js");
require("./server/methods/errorsMeta.js");
require("./server/methods/insights.js");
require("./server/methods/traceExplorer.js");
require("./server/publications/apps.js");
require("./server/publications/errorsMeta.js");
require("./server/publications/user.js");
require("./config/errorStatuses.js");
require("./config/permissions.js");
require("./config/plans.js");
//# sourceMappingURL=app.js.map
